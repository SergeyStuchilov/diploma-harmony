<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use App\Models\Slider;

class SliderSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        $sliders = [
            [
                'title' => 'Image 1',
                'url' => ''
            ],
            [
                'title' => 'Image 2',
                'url' => ''
            ],
            [
                'title' => 'Image 3',
                'url' => ''
            ]
        ];

        foreach ($sliders as $key => $value) {
            Slider::create($value);
        }
    }
}
