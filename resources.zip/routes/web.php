<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\AppController;
use App\Http\Controllers\ArticleController;
use App\Http\Controllers\AuthController;
use App\Http\Controllers\AuthorController;
use App\Http\Controllers\BlogController;
use App\Http\Controllers\BookController;
use App\Http\Controllers\CategoryController;
use App\Http\Controllers\ContactController;
use App\Http\Controllers\GalleryController;
use App\Http\Controllers\GenreController;
use App\Http\Controllers\PermissionController;
use App\Http\Controllers\RoleController;
use App\Http\Controllers\ServiceController;
use App\Http\Controllers\SliderController;
use App\Http\Controllers\UserController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/
// , 'isNotBan'

Route::middleware('locale')->group(function () {
    Route::get('/', [AppController::class, "mainPage"])->name("app.main");
    Route::get('lang/{lang}', [AppController::class, "changeLocale"])->name("app.change-lang");
    Route::get('catalog/genres/{genreSlug}', [AppController::class, "getProjectsByGenre"])->name("app.catalog-by-genre");
    Route::get('trends', [AppController::class, "trendPage"])->name("app.trends.page");
    Route::get('applications', [AppController::class, "applicationPage"])->name("app.applications.page");

    Route::get('services', [ServiceController::class, "servicePage"])->name("app.services.page");
    Route::get('services/compound', [ServiceController::class, "serviceCompound"])->name("app.services.compound");
    Route::get('services/design', [ServiceController::class, "serviceDesign"])->name("app.services.design");
    Route::get('services/interior', [ServiceController::class, "serviceInterior"])->name("app.services.interior");
    Route::get('services/online', [ServiceController::class, "serviceOnline"])->name("app.services.online");

    Route::get('gallerys', [GalleryController::class, "galleryPage"])->name("app.gallers.index");
    Route::get('gallerys/search',[GalleryController::class,"search"])->name('search');
    Route::get('gallerys/{bookSlug}', [GalleryController::class, "showBook"])->name("app.book.page");




    Route::get('contacts', [ContactController::class, "showContact"])->name("app.contacts.index");
    Route::post('contacts/page', [ContactController::class, "contactPage"])->name("app.contacts.page");

    Route::get('blogs', [BlogController::class, "showBlog"])->name("app.blogs.index");
    Route::get('blogs/brick', [BlogController::class, "blogBrick"])->name("app.blogs.brick");

    Route::get('sliders', [SliderController::class, 'index']);

    Route::middleware(['auth'])->group(function () {
        //Категории
        Route::prefix('categories')->group(function () {
            Route::get('/', [CategoryController::class, "categoriesList"])->name("categories.list");
            Route::get('create', [CategoryController::class, "createCategory"])->name("categories.create");
            Route::post('create', [CategoryController::class, "storeCategory"])->name("categories.store");
            Route::get('{categoryId}/edit', [CategoryController::class, "editCategory"])->name("categories.edit");
            Route::put('{categoryId}/edit', [CategoryController::class, "updateCategory"])->name("categories.update");
            Route::delete('{categoryId}', [CategoryController::class, "deleteCategory"])->name("categories.delete");
        });

        //Новости
        Route::prefix('articles')->group(function () {
            Route::get('/', [ArticleController::class, "index"])->name("articles.index");
            Route::get('create', [ArticleController::class, "create"])->name("articles.create");
            Route::post('create', [ArticleController::class, "store"])->name("articles.store");
            Route::get('{articleId}/edit', [ArticleController::class, "edit"])->name("articles.edit");
            Route::put('{articleId}/edit', [ArticleController::class, "update"])->name("articles.update");
            Route::delete('{articleId}', [ArticleController::class, "delete"])->name("articles.delete");
            Route::get('{articleSlug}', [ArticleController::class, "show"])->name("articles.show");
            Route::get('{articleId}/remove-image', [ArticleController::class, "removeImage"])->name("articles.remove-image");
        });

        //Жанры
        Route::resource('genres', GenreController::class)->middleware(['role:super-admin|admin|moderator']);

        //Авторы
        Route::resource('authors', AuthorController::class)->middleware(['role:super-admin|admin|moderator']);

        //Проекты
        Route::prefix('books')->group(function () {

            Route::get('/', [BookController::class, 'index'])->name("books.index");
            Route::get('create', [BookController::class, 'create'])->name("books.create");
            Route::post('create', [BookController::class, 'store'])->name("books.store");
            Route::get('{book}/edit', [BookController::class, 'edit'])->name("books.edit");
            Route::put('{book}/edit', [BookController::class, 'update'])->name("books.update");
            Route::delete('{book}', [BookController::class, 'destroy'])->name("books.destroy");
            Route::get('{bookSlug}', [BookController::class, 'show'])->name("books.show");
            Route::get('{book}/remove-image', [BookController::class, "removeImage"])->name("books.remove-image");
        });

        //Пользователи
        Route::prefix('users')->middleware('role:super-admin|admin')->group(function () {
            Route::get('/', [UserController::class, 'index'])->name("users.index");
            Route::get('{user}/edit', [UserController::class, 'edit'])->name("users.edit");
            Route::put('{user}/edit', [UserController::class, 'update'])->name("users.update");
            Route::put('{user}/ban', [UserController::class, 'banUsers'])->name("users.ban");
            Route::delete('{user}', [UserController::class, 'destroy'])->name("user.destroy");
        });

        //Роли
        Route::prefix('roles')->middleware('role:super-admin')->group(function () {
            Route::get('/', [RoleController::class, 'index'])->name("roles.index");
            Route::get('create', [RoleController::class, 'create'])->name("roles.create");
            Route::post('create', [RoleController::class, 'store'])->name("roles.store");
            Route::get('{role}/edit', [RoleController::class, 'edit'])->name("roles.edit");
            Route::put('{role}/edit', [RoleController::class, 'update'])->name("roles.update");
        });

        //Права
        Route::prefix('permissions')->middleware('role:super-admin')->group(function () {
            Route::get('/', [PermissionController::class, 'index'])->name("permissions.index");
            Route::get('create', [PermissionController::class, 'create'])->name("permissions.create");
            Route::post('create', [PermissionController::class, 'store'])->name("permissions.store");

        });

        Route::post('logout', [AuthController::class, 'logout'])->name("auth.logout");
    });

    Route::middleware(["guest"])->group(function () {
        // Регистрация
        Route::get('register', [AuthController::class, 'registerPage'])->name("auth.register");
        Route::post('register', [AuthController::class, 'storeUser'])->name("auth.store-user");
        Route::get('login', [AuthController::class, 'loginPage'])->name("auth.login-page");
        Route::post('login', [AuthController::class, 'login'])->name("auth.login");
    });

});

