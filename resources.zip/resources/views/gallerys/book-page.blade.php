@extends('app')

@section('title', 'Проект')

@section('content')

    <div class="row">
        <div class="card ">
            <img class="opacity-25" src="{{ asset('assets/images/glavnaya_resize.jpg') }}" alt="">
            <div class="card-img-overlay overflow-auto d-flex flex-column">
                <div class="d-flex  align-items-center my-5">
                    <h2>{{ __('Проект') }}</h2>
                </div>
                <div class="row">

                    <div class="project-block">
                        <img src="{{ $book->getImage() }}" class="project-block-image" alt="">
                    </div>

                    <div class="mt-5 p-5">
                        <h1 class="mb-3">{{ $book->title }}</h1>
                        <div class="mb-3">{!! $book->getGenres() !!}</div>
                        <div class="mb-3">{{ $book->getPrice() }}</div>
                        <div class="mb-3">
                            <p>{!! $book->description !!}</p>
                        </div>
                    </div>

                </div>
            </div>
        </div>
    </div>








@endsection
