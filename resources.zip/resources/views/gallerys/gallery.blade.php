@extends('app')

@section('title', __('Галерея'))

@section('content')
    <div class="row">
        <div class="card ">
            <img class="opacity-25" src="{{ asset('assets/images/glavnaya_resize.jpg') }}" alt="">
            <div class="card-img-overlay overflow-auto d-flex flex-column">
                <div class="d-flex align-items-center justify-content-between mb-2">
                    <h1 class="my-2">{{ __('Галерея') }}</h1>
                </div>
                <div class="d-flex justify-content-end">
                    <form method="GET" action="{{ route('search') }}" class="d-flex mx-2" role="search">
                        <input class="form-control me-2" type="text" name="search_books" placeholder="Введите запрос"
                            aria-label="Search" value="{{ request()->search_books }}">
                        <button class="btn btn-outline-success" type="submit">Найти</button>
                    </form>
                    <a href="{{ route('app.gallers.index') }}" class="btn btn-primary">Сбросить фильтр</a>
                </div>
                <div class="card ">
                    <div class="card-img-overlay">
                        <div class="row d-flex justify-content-evenly">
                            @foreach ($books as $book)
                                <div class="col-lg-3 col-md-4 col-6 m-3">
                                    <div class="card mb-3">
                                        <img src="{{ $book->getImage() }}" class="card-img-top" alt="...">
                                        <div class="card-body">
                                            <h5 class="card-title">{{ $book->title }}</h5>
                                            <p class="card-text">Стоимость от {{ $book->getPrice() }} за 1 м²</p>
                                            <a href="{{ route('app.book.page', $book->slug) }}"
                                                class="btn btn-primary">Перейти</a>
                                        </div>
                                    </div>
                                </div>
                            @endforeach
                        </div>
                        <div class="btn-toolbar justify-content-center" role="toolbar"
                            aria-label="Toolbar with button groups">
                            <div class="btn-group me-2" role="group" aria-label="First group">
                                @if ($books->currentPage() != 1)
                                    <a href="{{ $books->previousPageUrl() }}" type="button"
                                        class="btn btn-lg btn-primary"><span aria-hidden="true">&laquo;</span></a>
                                @endif
                                @for ($i = 1; $i <= $books->LastPage(); $i++)
                                    <a href="{{ $books->url($i) }}" type="button"
                                        class="btn btn-lg @if ($i == $books->currentPage()) btn-primary @else btn-outline-primary @endif">{{ $i }}</a>
                                @endfor
                                @if ($books->currentPage() != $books->lastPage())
                                    <a href="{{ $books->nextPageUrl() }}" type="button"
                                        class="btn btn-lg btn-primary"><span aria-hidden="true">&raquo;</span></a>
                                @endif
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection
