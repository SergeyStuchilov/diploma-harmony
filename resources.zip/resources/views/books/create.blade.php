@extends('app')

@section('title', __('Новый проект'))
@section('content')

    <div class="row">
        <div class="card ">
            <img class="opacity-25" src="{{ asset('assets/images/glavnaya_resize.jpg') }}" alt="">
            <div class="card-img-overlay overflow-auto d-flex flex-column">
                <div class="d-flex justify-content-between align-items-center my-5">
                    <h2>{{ __('Новый проект') }}</h2>
                </div>
                <div>
                    <form action="{{ route('books.store') }}" method="POST" enctype="multipart/form-data">
                        @csrf
                        <div class="form-group mb-3">
                            <label for="title" class="form-label">Название проекта</label>
                            <input type="text" id="title" name="title" class="form-control"
                                value="{{ old('title') }}">
                            @error('title')
                                <small class="text-danger">{{ $message }}</small>
                            @enderror
                        </div>
                        <div class="form-group mb-3">
                            <label for="description" class="form-label">Описание</label>
                            <textarea name="description" id="description" class="form-control">{{ old('description') }}</textarea>
                            @error('description')
                                <small class="text-danger">{{ $message }}</small>
                            @enderror
                        </div>
                        <div class="form-group mb-3">
                            <label for="publish_date" class="form-label">Дата публикации</label>
                            <input type="date" id="publish_date" name="publish_date" class="form-control"
                                value="{{ old('publish_date') }}">
                            @error('publish_date')
                                <small class="text-danger">{{ $message }}</small>
                            @enderror
                        </div>
                        <div class="form-group mb-3">
                            <label for="price" class="form-label">Стоимость от</label>
                            <input type="number" id="price" name="price" class="form-control"
                                value="{{ old('price') }}">
                            @error('price')
                                <small class="text-danger">{{ $message }}</small>
                            @enderror
                        </div>
                        <div class="form-group mb-3">
                            <label for="image" class="form-label">Изображение</label>
                            <input type="file" id="image" name="image" class="form-control">
                            @error('image')
                                <small class="text-danger">{{ $message }}</small>
                            @enderror
                        </div>
                        <div class="form-check mb-3">
                            <p>Стили проекта</p>
                            @foreach ($genres as $genre)
                                <label class="form-label mx-3" for="{{ 'genre_' . $genre->id }}">
                                    <input class="form-check-input" type="checkbox" id="{{ 'genre_' . $genre->id }}"
                                        name="genres[]" value="{{ $genre->id }}"
                                        @if (old('genre_' . $genre->id) == $genre->id) checked @endif>
                                    {{ $genre->name }}
                                </label>
                            @endforeach
                        </div>
                        <button type="submit" class="btn btn-dark btn-lg">Создать</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
@endsection
