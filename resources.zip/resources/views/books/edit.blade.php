@extends('app')

@section('title', $book->title . ' (ред.)')
@section('content')
    <div class="row">
        <div class="card ">
            <img class="opacity-25" src="{{ asset('assets/images/glavnaya_resize.jpg') }}" alt="">
            <div class="card-img-overlay overflow-auto d-flex flex-column">
                <div class="d-flex justify-content-between align-items-center my-3">
                    <h2>{{ $book->title . ' (ред.)' }}</h2>
                </div>
                <div>
                    <form action="{{ route('books.update', $book) }}" method="POST" enctype="multipart/form-data">
                        @csrf @method('PUT')
                        <div class="form-group mb-3">
                            <label for="title" class="form-label">Название проекта</label>
                            <input type="text" id="title" name="title" class="form-control"
                                value="{{ old('title', $book->title) }}">
                            @error('title')
                                <small class="text-danger">{{ $message }}</small>
                            @enderror
                        </div>
                        <div class="form-group mb-3">
                            <label for="description" class="form-label">Описание</label>
                            <textarea name="description" id="description" class="form-control">{{ old('description', $book->description) }}</textarea>
                            @error('description')
                                <small class="text-danger">{{ $message }}</small>
                            @enderror
                        </div>
                        <div class="form-group mb-3">
                            <label for="publish_date" class="form-label">Дата публикации</label>
                            <input type="date" id="publish_date" name="publish_date" class="form-control"
                                value="{{ old('publish_date', $book->publish_date) }}">
                            @error('publish_date')
                                <small class="text-danger">{{ $message }}</small>
                            @enderror
                        </div>
                        <div class="form-group mb-3">
                            <label for="price" class="form-label">Стоимость</label>
                            <input type="number" id="price" name="price" class="form-control"
                                value="{{ old('price', $book->price) }}">
                            @error('price')
                                <small class="text-danger">{{ $message }}</small>
                            @enderror
                        </div>
                        <div class="form-group mb-3">
                            <label for="image" class="form-label">Изображение</label>
                            <input type="file" id="image" name="image" class="form-control">
                            @error('image')
                                <small class="text-danger">{{ $message }}</small>
                            @enderror
                            @if ($book->image)
                                <div>
                                    <img src="{{ $book->getImage() }}" alt="" style="width: 150px">
                                </div>
                                <a href="{{ route('books.remove-image', $book->id) }}"
                                    class="btn btn-sm btn-danger">Удалить
                                    изображение</a>
                            @endif
                        </div>
                        <div class="form-group mb-3">
                            <p>Стили проекта</p>
                            @foreach ($genres as $genre)
                                <label for="{{ 'genre_' . $genre->id }}" class="form-label">
                                    <input type="checkbox" id="{{ 'genre_' . $genre->id }}" name="genres[]"
                                        class="form-check-input" value="{{ $genre->id }}"
                                        @if ($book->genres->contains(old('genre_' . $genre->id, $genre->id))) checked @endif>
                                    {{ $genre->name }}
                                </label>
                            @endforeach
                        </div>
                        <button type="submit" class="btn btn-dark btn-lg">Сохранить</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
@endsection
