@extends('app')

@section('title', __('Проекты'))
@section('content')
    <div class="row">
        <div class="card ">
            <img class="opacity-25" src="{{ asset('assets/images/glavnaya_resize.jpg') }}" alt="">
            <div class="card-img-overlay overflow-auto d-flex flex-column">
                <div class="d-flex justify-content-between align-items-center my-5">
                    <h2>{{ __('Проекты') }}</h2>
                    <a href="{{ route('books.create') }}" class="btn btn-dark btn-lg">Добавить</a>
                </div>
                <div>
                    <table class="table table-striped">
                        <thead>
                            <tr>
                                <th>{{ __('Картинка') }}</th>
                                <th>{{ __('Проект') }}</th>
                                <th>{{ __('Стоимость') }}</th>
                                <th>{{ __('Дата') }}</th>
                                <th>{{ __('Стили') }}</th>
                                <th>Действия</th>
                            </tr>
                        </thead>
                        <tbody>
                            @foreach ($books as $book)
                                <tr>
                                    <td><img src="{{ $book->getImage() }}" alt="" style="height: 80px"></td>
                                    <td>{{ $book->title }}</td>
                                    <td>{{ $book->getPrice() }}</td>
                                    <td>{{ $book->publish_date }}</td>
                                    <td>
                                        @foreach ($book->genres as $genre)
                                            {!! $genre->name . '<br>' !!}
                                        @endforeach
                                    </td>
                                    <td class="d-flex justify-content-around">
                                        <a href="{{ route('books.edit', $book) }}" class="btn btn-sm btn-warning">Ред.</a>
                                        <form action="{{ route('books.destroy', $book) }}" method="POST" class="mx-3">
                                            @csrf @method('DELETE')
                                            <button type="submit" class="btn btn-sm btn-danger"
                                                onclick="event.preventDefault();if(confirm('Запись будет удалена. Продолжить?')){this.closest('form').submit();}">Удалить</button>
                                        </form>
                                    </td>
                                </tr>
                            @endforeach
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
@endsection
