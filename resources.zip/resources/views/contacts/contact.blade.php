@extends('app')

@section('title', __('Контакт'))

@section('content')

    <div class="row">
        <div class="card ">
            <div class="">
                <div class="contact-background-first"></div>
                <div class="contact-background-second"></div>
            </div>
            <div class="card-img-overlay contact-block">

                <div class="row d-flex mt-3 mx-3 contact-block-mail">
                    <div class="col-6 contact-block-image mx-3">
                        <img src="{{ asset('assets/images/metallicheskie-pochtovye-yashchiki 1.jpg') }}" alt="">
                    </div>
                    <div class="col-5 offset-5 ms-auto">
                        <p class="contact-block-text">
                            <strong>Адрес:</strong>
                            "г.Сургут, ул.Югорский трак 38"
                            <br>
                            <strong>Телефон:</strong>
                            <a href="phone:83462777888"></a>
                            "+7 (3462) <span style="font-weight:700;">77-78-88</span>"
                            <br>
                            <strong>Email:</strong>
                            <a href="">ssergei73@mail.ru</a>
                        </p>
                        <p class="contact-block-text">
                            <strong>Режим работы:</strong>
                            <br>
                            "Пн. - Пт.: с 10-00 до 18-00"
                        </p>
                    </div>
                </div>
                <div class="row d-flex mt-3 mx-3 contact-block-mail">
                    <div class="contact-block-form col-6 text-bg-dark mx-3">
                        <h2>Наши контакты</h2>
                        <p>Мы всегда рады Вашему визиту, звонку или письму!</p>
                        <section class="form">
                            <div class="row">

                                <div class="col-10 offset-1">
                                    <div class="row">
                                        <form action="{{route('auth.store-user')}}" method="POST">
                                            @csrf
                                            <div class="d-sm-flex justify-content-between flex-column">
                                                <div class="d-flex flex-wrap col-12">
                                                    <label for="name" class="form-label fw-bold">Имя:</label>
                                                    <input type="text" class="form-control" id="name" value="{{ old('name') }}" required>
                                                </div>
                                                <div class="d-flex flex-wrap col-12 mt-3">
                                                    <label for="email" class="form-label fw-bold">Email:</label>
                                                    <input type="email" class="form-control" name="email" id="email" value="{{ old('email') }}" required>
                                                </div>
                                                <div class="d-flex flex-wrap col-12 mt-3">
                                                    <label for="phone" class="form-label fw-bold">Телефон:</label>
                                                    <input type="text" class="form-control" id="phone" required>
                                                </div>
                                            </div>
                                            <div class="d-flex my-4 flex-wrap">
                                                <h5 class="fw-bold">Свяжитесь со мной через:</h5>
                                                <div class="d-flex">
                                                    <div class="form-check mx-4">
                                                        <input class="form-check-input" type="radio"
                                                            name="inlineRadioOptions" id="inlineRadio1" value="option1">
                                                        <label class="form-check-label fw-bold"
                                                            for="inlineRadio1">Email</label>
                                                    </div>
                                                    <div class="form-check mx-4">
                                                        <input class="form-check-input" type="radio"
                                                            name="inlineRadioOptions" id="phone" value="option2">
                                                        <label class="form-check-label fw-bold"
                                                            for="phone">Телефон</label>
                                                    </div>
                                                    <div class="form-check mx-4">
                                                        <input class="form-check-input" type="radio"
                                                            name="inlineRadioOptions" id="inlineRadio2" value="option2">
                                                        <label class="form-check-label fw-bold"
                                                            for="inlineRadio2">Мессенджер</label>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="d-flex my-4 flex-wrap">
                                                <h5 class="fw-bold">Тема:</h5>
                                                <select class="form-select" aria-label="Default select example">
                                                    <option selected>Post my story</option>
                                                    <option value="1">First story</option>
                                                    <option value="2">Second story</option>
                                                    <option value="3">Third story</option>
                                                </select>
                                            </div>
                                            <div class="my-3">
                                                <h5 class="fw-bold text-start">Сообщение:</h5>
                                                <div class="form-floating">
                                                    <textarea class="form-control" placeholder="Leave a comment here" id="floatingTextarea2" style="height: 130px"></textarea>
                                                    <label for="floatingTextarea2"></label>
                                                </div>
                                            </div>
                                            <div class="form-check d-flex justify-content-between">
                                                <div>
                                                    <input class="form-check-input" type="checkbox" value=""
                                                        id="invalidCheck2" required>
                                                    <label class="form-check-label fw-bold" for="invalidCheck2">
                                                        Я человек
                                                    </label>
                                                </div>
                                                <button type="submit" class="btn btn-outline-secondary">Отправить</button>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </section>
                    </div>
                    <div class="row col-5 offset-5 ms-auto mx-2" id="map">
                        <iframe
                            src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d1919.7045186492012!2d73.37126187739!3d61.2394064566914!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x43739a01cdb1e241%3A0x53fae2a98ce1e52a!2z0KLQoNCmIMKr0KHRg9GA0LPRg9GCINCh0LjRgtC4INCc0L7Qu9C7wrs!5e0!3m2!1sru!2sru!4v1713009156683!5m2!1sru!2sru"
                            width="600" height="745" style="border:0;" allowfullscreen="" loading="lazy"
                            referrerpolicy="no-referrer-when-downgrade"></iframe>
                    </div>
                </div>
            </div>
        </div>
    </div>

@endsection

@section('page-scripts')
    <script src="{{ asset('assets/js/jquery.inputmask.min.js') }}"></script>
@endsection
