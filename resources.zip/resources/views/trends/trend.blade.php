@extends('app')

@section('title', 'Тренды интерьера')

@section('content')
    <div class="row">
        <div class="card ">
            <img class="opacity-25" src="{{ asset('assets/images/glavnaya_resize.jpg') }}" alt="">
            <div class="card-img-overlay overflow-auto text-start px-5 mx-4">
                <h2 class="my-3 text-center">{{ __('Тренды интерьера') }}</h2>
                <p>Существует много оригинальных приемов оформления помещений, но конкретный выбор стиля в интерьере –
                    задача, важность которой невозможно переоценить, ведь от правильно выбранного стиля интерьера дома
                    зависит Ваш эмоциональный фон и работоспособность, комфорт и гармония Вашей жизни.</p>
                <div class="row fw-semibold text-center">
                    <div class="row d-flex justify-content-between px-4 my-5 ">
                        <div class="block-img-one">
                            <img src="{{ asset('assets/images/shale_7 2.jpg') }}" alt="">
                            <div class="block-img-one-text">
                                <p class="mt-3">Стиль Шале в интерьере</p>
                            </div>
                        </div>
                        <div class="block-img-one">
                            <img src="{{ asset('assets/images/kontemporari_10 1.jpg') }}" alt="">
                            <div class="block-img-one-text">
                                <p class="mt-3">Стиль контемпорари</p>
                            </div>
                        </div>
                        <div class="block-img-one">
                            <img src="{{ asset('assets/images/minimalizm_stil_10 1.jpg') }}" alt="">
                            <div class="block-img-one-text">
                                <p class="mt-3">Стиль Минимализм</p>
                            </div>
                        </div>
                        <div class="block-img-one">
                            <img src="{{ asset('assets/images/angl_1 1.jpg') }}" alt="">
                            <div class="block-img-one-text">
                                <p class="mt-3">Английский стиль интерьера</p>
                            </div>
                        </div>
                        <div class="block-img-one">
                            <img src="{{ asset('assets/images/kantri_3 1.jpg') }}" alt="">
                            <div class="block-img-one-text">
                                <p class="mt-3">Стиль Кантри в интерьере</p>
                            </div>
                        </div>
                    </div>

                    <div class="row d-flex justify-content-between px-4 my-5">
                        <div class="block-img-one">
                            <img src="{{ asset('assets/images/vintage_8 4.jpg') }}" alt="">
                            <div class="block-img-one-text">
                                <p class="mt-3">Стиль Винтаж в интерьере</p>
                            </div>
                        </div>
                        <div class="block-img-one">
                            <img src="{{ asset('assets/images/provans_1 4.jpg') }}" alt="">
                            <div class="block-img-one-text">
                                <p class="mt-3">Стиль Прованс</p>
                            </div>
                        </div>
                        <div class="block-img-one">
                            <img src="{{ asset('assets/images/art_nuvo_2 1.jpg') }}" alt="">
                            <div class="block-img-one-text">
                                <p class="mt-3">Стиль Арт-нуво</p>
                            </div>
                        </div>
                        <div class="block-img-one">
                            <img src="{{ asset('assets/images/baro_10 1.jpg') }}" alt="">
                            <div class="block-img-one-text">
                                <p class="mt-3">Стиль "Барокко" в интерьере</p>
                            </div>
                        </div>
                        <div class="block-img-one">
                            <img src="{{ asset('assets/images/kla_7 1.jpg') }}" alt="">
                            <div class="block-img-one-text">
                                <p class="mt-3">Классический стиль</p>
                            </div>
                        </div>
                    </div>

                    <div class="row d-flex justify-content-between px-4 my-5">
                        <div class="block-img-one">
                            <img src="{{ asset('assets/images/sheby_shik1 3.jpg') }}" alt="">
                            <div class="block-img-one-text">
                                <p class="mt-3">Шебби-шик в интерьере</p>
                            </div>
                        </div>
                        <div class="block-img-one">
                            <img src="{{ asset('assets/images/skandi_4 1.jpg') }}" alt="">
                            <div class="block-img-one-text">
                                <p class="mt-3">Скандинавский стиль</p>
                            </div>
                        </div>
                        <div class="block-img-one">
                            <img src="{{ asset('assets/images/pechvorck_7 1.jpg') }}" alt="">
                            <div class="block-img-one-text">
                                <p class="mt-3">Стиль Пэчворк в интерьере</p>
                            </div>
                        </div>
                        <div class="block-img-one">
                            <img src="{{ asset('assets/images/ant_2 1.jpg') }}" alt="">
                            <div class="block-img-one-text">
                                <p class="mt-3">Античный стиль в интерьере</p>
                            </div>
                        </div>
                        <div class="block-img-one">
                            <img src="{{ asset('assets/images/interer-v-yaponskom-stile-foto-interera-10 1.jpg') }}"
                                alt="">
                            <div class="block-img-one-text">
                                <p class="mt-3">Китайский стиль в интерьере</p>
                            </div>
                        </div>
                    </div>

                    <div class="row d-flex justify-content-between px-4 my-5">
                        <div class="block-img-one">
                            <img src="{{ asset('assets/images/bionika_1 1.jpg') }}" alt="">
                            <div class="block-img-one-text">
                                <p class="mt-3">Стиль "Бионика"</p>
                            </div>
                        </div>
                        <div class="block-img-one">
                            <img src="{{ asset('assets/images/hay_1 1.jpg') }}" alt="">
                            <div class="block-img-one-text">
                                <p class="mt-3">Стиль хай-тек"</p>
                            </div>
                        </div>
                        <div class="block-img-one">
                            <img src="{{ asset('assets/images/3 1.jpg') }}" alt="">
                            <div class="block-img-one-text">
                                <p class="mt-3">Стиль Авангард"</p>
                            </div>
                        </div>
                        <div class="block-img-one">
                            <img src="{{ asset('assets/images/shvedskiy_styl 1.jpg') }}" alt="">
                            <div class="block-img-one-text">
                                <p class="mt-3">Шведский стиль"</p>
                            </div>
                        </div>
                        <div class="block-img-one">
                            <img src="{{ asset('assets/images/etnicheskiy_1 1.jpg') }}" alt="">
                            <div class="block-img-one-text">
                                <p class="mt-3">Этнический стиль"</p>
                            </div>
                        </div>
                    </div>

                    <div class="row d-flex justify-content-between px-4 my-5">
                        <div class="block-img-one">
                            <img src="{{ asset('assets/images/afri_1 1.jpg') }}" alt="">
                            <div class="block-img-one-text">
                                <p class="mt-3">Африканский стиль"</p>
                            </div>
                        </div>
                        <div class="block-img-one">
                            <img src="{{ asset('assets/images/indiya_6 1.jpg') }}" alt="">
                            <div class="block-img-one-text">
                                <p class="mt-3">Индийский стиль в интерьере"</p>
                            </div>
                        </div>
                        <div class="block-img-one">
                            <img src="{{ asset('assets/images/loft_1 1.jpg') }}" alt="">
                            <div class="block-img-one-text">
                                <p class="mt-3">Стиль лофт в интерьере"</p>
                            </div>
                        </div>
                        <div class="block-img-one">
                            <img src="{{ asset('assets/images/eklektika_10 1.jpg') }}" alt="">
                            <div class="block-img-one-text">
                                <p class="mt-3">Эклектика в интерьере"</p>
                            </div>
                        </div>
                        <div class="block-img-one">
                            <img src="{{ asset('assets/images/japan_10 1.jpg') }}" alt="">
                            <div class="block-img-one-text">
                                <p class="mt-3">Японский стиль"</p>
                            </div>
                        </div>
                    </div>

                    <div class="row d-flex justify-content-between px-4 my-5">
                        <div class="block-img-one">
                            <img src="{{ asset('assets/images/vostok_stil_10 1.jpg') }}" alt="">
                            <div class="block-img-one-text">
                                <p class="mt-3">Восточный стиль"</p>
                            </div>
                        </div>
                        <div class="block-img-one">
                            <img src="{{ asset('assets/images/gotika_vid_9 5.jpg') }}" alt="">
                            <div class="block-img-one-text">
                                <p class="mt-3">Готический стиль"</p>
                            </div>
                        </div>
                        <div class="block-img-one">
                            <img src="{{ asset('assets/images/baro_10 1.jpg') }}" alt="">
                            <div class="block-img-one-text">
                                <p class="mt-3">Исторические стили"</p>
                            </div>
                        </div>
                    </div>

                </div>
                <p>
                    Мы предлагаем ознакомиться со всеми основными и популярными стилями в интерьере, основным описанием
                    стилей для оформления квартиры или коттеджа, спроектируйте интерьер таким образом, чтобы прослеживалась
                    общая концепция определенного стиля и все его элементы интерьера гармонично вписывались в общий колорит.
                    Создайте цельный облик – определенный стиль и характер помещения.
                </p>
                <p class="text-center fw-bolder fs-5">Мы будем рады вам помочь выбрать ваш стиль.</p>
                <button type="button" class="btn btn-md btn-dark d-grid gap-2 col-6 mx-auto">Подробнее</button>
            </div>
        </div>
    </div>
@endsection
