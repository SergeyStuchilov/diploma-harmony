@extends('app')

@section('title', __('Каталог'))

@section('content')

    <div class="row">
        <div class="card ">
            <div class="gallery-block"></div>
            {{-- <img class="opacity-25" src="{{ asset('assets/images/glavnaya_resize.jpg') }}" alt=""> --}}
            <div class="card-img-overlay">
                <div class="row d-flex justify-content-evenly">
                    @foreach ($books as $book)
                        <div class="col-lg-3 col-md-4 col-6 m-3">
                            <div class="card mb-3">
                                <img src="{{ $book->getImage() }}" class="card-img-top" alt="...">
                                <div class="card-body">
                                    <h5 class="card-title">{{ $book->title }}</h5>
                                    <p class="card-text">Стоимость от {{ $book->getPrice() }} за 1 м²</p>
                                    <a href="{{ route('app.book.page', $book->slug) }}" class="btn btn-primary">Перейти</a>
                                </div>
                            </div>
                        </div>
                    @endforeach
                </div>
            </div>
        </div>
    </div>
@endsection
