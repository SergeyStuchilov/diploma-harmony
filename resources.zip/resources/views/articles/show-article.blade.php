@extends('app')

@section('title', 'Тема')
@section('content')
    <div class="row">
        <div class="card ">
            <img class="opacity-25" src="{{ asset('assets/images/glavnaya_resize.jpg') }}" alt="">
            <div class="card-img-overlay overflow-auto d-flex flex-column">
                <div class="d-flex justify-content-between align-items-center my-5">
                    <h2>Тема</h2>
                    <a href="{{ route('articles.create') }}" class="btn btn-dark btn-lg">Добавить</a>
                </div>
                <div>
                    <h1>{{ $article->title }}</h1>
                    <p>{{ $article->content }}</p>
                    <p>Категории: {{ $article->category->name }}</p>
                </div>
            </div>
        </div>
    </div>
@endsection
