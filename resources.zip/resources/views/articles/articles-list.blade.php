@extends('app')

@section('title', __('Тема'))
@section('content')
    <div class="row">
        <div class="card ">
            <img class="opacity-25" src="{{ asset('assets/images/glavnaya_resize.jpg') }}" alt="">
            <div class="card-img-overlay overflow-auto d-flex flex-column">
                <div class="d-flex justify-content-between align-items-center my-5">
                    <h2>{{ __('Тема') }}</h2>
                    <a href="{{ route('articles.create') }}" class="btn btn-dark btn-lg">Добавить</a>
                </div>
                @if (session('success'))
                    <div class="alert alert-success">
                        {{ session('success') }}
                    </div>
                @endif
                <div>
                    @if ($articles->count())
                        <table class="table table-striped">
                            <thead>
                                <tr>
                                    <th>Изображение</th>
                                    <th>Заголовок</th>
                                    <th>Категория</th>
                                    <th>Опубликовано</th>
                                    <th>Действие</th>
                                </tr>
                            </thead>
                            <tbody>
                                @foreach ($articles as $article)
                                    <tr>
                                        <td>
                                            <img src="{{ $article->getImage() }}" alt="" style="height: 80px">
                                        </td>
                                        <td>
                                            <a href="{{ route('articles.show', $article->slug) }}">
                                                {{ $article->title }}
                                            </a>
                                        </td>
                                        <td>{{ $article->category->name }}</td>
                                        <td>{!! $article->getPublishStatus() !!}</td>
                                        <td class="d-flex justify-content-around">
                                            <a href="{{ route('articles.edit', $article) }}"
                                                class="btn btn-sm btn-warning">Ред.</a>
                                            <form action="{{ route('articles.delete', $article) }}" method="POST"
                                                class="mx-3">
                                                @csrf @method('DELETE')
                                                <button type="submit" class="btn btn-sm btn-danger"
                                                    onclick="event.preventDefault();if(confirm('Запись будет удалена. Продолжить?')){this.closest('form').submit();}">
                                                    Удалить
                                                </button>
                                            </form>
                                        </td>
                                    </tr>
                                @endforeach
                            </tbody>
                        </table>
                    @else
                        <p class="my-4">Пока нет ни одной новости.</p>
                    @endif
                </div>
            </div>
        </div>
    </div>
@endsection
