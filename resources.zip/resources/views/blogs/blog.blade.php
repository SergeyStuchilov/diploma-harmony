@extends('app')

@section('title', __('Блок'))

@section('content')

    <div class="row">
        <div class="card ">
            <img class="opacity-25" src="{{ asset('assets/images/glavnaya_resize.jpg') }}" alt="">
            <div class="card-img-overlay overflow-auto text-start px-5 mx-4">

                <div class="row fw-semibold text-center">
                    <div class="d-flex justify-content-evenly px-4 my-5 ">
                        <div class="block-img-one">
                            <img src="{{ asset('assets/images/kirpichnaya-stena-v-interere27 1.jpg') }}" alt="">
                            <div class="block-img-one-text">
                                <p class="mt-3">Кирпичная стена в интерьере:
                                    брутальный акцент</p>
                            </div>
                            <a href="{{route('app.blogs.brick')}}" type="button" class="btn btn-secondary">Посмотреть</a>
                        </div>
                        <div class="block-img-one">
                            <img src="{{ asset('assets/images/Mramor-v-dizaine-kukhni9 1.jpg') }}" alt="">
                            <div class="block-img-one-text">
                                <p class="mt-3">Мрамор в дизайне кухни:
                                    актуальная элегантность</p>
                            </div>
                        </div>
                        <div class="block-img-one">
                            <img src="{{ asset('assets/images/Serebro-v-interere18 1.jpg') }}" alt="">
                            <div class="block-img-one-text">
                                <p class="mt-3">Серебро в интерьере:
                                    скромно, но драгоценно</p>
                            </div>
                        </div>
                        <div class="block-img-one">
                            <img src="{{ asset('assets/images/napolnyie-vazyi-v-nterere20 1.jpg') }}" alt="">
                            <div class="block-img-one-text">
                                <p class="mt-3">Напольные вазы в интерьере:
                                    стабильная красота</p>
                            </div>
                        </div>
                        <div class="block-img-one">
                            <img src="{{ asset('assets/images/ELLE-zast 1.jpg') }}" alt="">
                            <div class="block-img-one-text">
                                <p class="mt-3">Журнал “ELLE Decoration”,
                                    Интернет-версия</p>
                            </div>
                        </div>
                    </div>

                    <div class="d-flex justify-content-evenly px-4 my-5">
                        <div class="block-img-one">
                            <img src="{{ asset('assets/images/kamin-v-interere-kvartiryr17 1.jpg') }}" alt="">
                            <div class="block-img-one-text">
                                <p class="mt-3">Камин в интерьере:
                                    идеи оформления</p>
                            </div>
                        </div>
                        <div class="block-img-one">
                            <img src="{{ asset('assets/images/Steampunk-interior19 1.jpg') }}" alt="">
                            <div class="block-img-one-text">
                                <p class="mt-3">Интерьер в стиле стимпанк:
                                    неординарное решение</p>
                            </div>
                        </div>
                        <div class="block-img-one">
                            <img src="{{ asset('assets/images/Myatnyi-tsvet-v-interere17 1.jpg') }}" alt="">
                            <div class="block-img-one-text">
                                <p class="mt-3">Мятный цвет в интерьере:
                                    свежо предание</p>
                            </div>
                        </div>
                        <div class="block-img-one">
                            <img src="{{ asset('assets/images/Intererdizain-zast 1.jpg') }}" alt="">
                            <div class="block-img-one-text">
                                <p class="mt-3">Журнал “Интерьер + дизайн”,
                                    Интернет-версия</p>
                            </div>
                        </div>
                        <div class="block-img-one">
                            <img src="{{ asset('assets/images/yellow-interior24 1.jpg') }}" alt="">
                            <div class="block-img-one-text">
                                <p class="mt-3">Желтый интерьер:
                                    солнечные сочетания</p>
                            </div>
                        </div>

                    </div>





                </div>

            </div>
        </div>


    </div>



@endsection
