@extends('app')

@section('title', $category->name . ' (ред.)')
@section('content')
    <div class="row">
        <div class="card ">
            <img class="opacity-25" src="{{ asset('assets/images/glavnaya_resize.jpg') }}" alt="">
            <div class="card-img-overlay overflow-auto d-flex flex-column">
                <div class="d-flex justify-content-between align-items-center my-5">
                    <h2>{{ $category->name . ' (ред.)' }}</h2>
                </div>
                <div>
                    <form action="{{ route('categories.update', $category->id) }}" method="POST">
                        @csrf @method('PUT')
                        <div class="form-group mb-3">
                            <label for="name" class="form-label">Название категории</label>
                            <input type="text" id="name" name="name" value="{{ $category->name }}"
                                class="form-control">
                        </div>
                        <button type="submit" class="btn btn-dark btn-lg">Сохранить</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
@endsection
