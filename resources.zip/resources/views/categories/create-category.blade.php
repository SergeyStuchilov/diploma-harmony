@extends('app')

@section('title', __('Новая категория'))
@section('content')
    <div class="row">
        <div class="card ">
            <img class="opacity-25" src="{{ asset('assets/images/glavnaya_resize.jpg') }}" alt="">
            <div class="card-img-overlay overflow-auto d-flex flex-column">
                <div class="d-flex justify-content-between align-items-center my-5">
                    <h2>{{ __('Новая категория') }}</h2>
                </div>
                <div>
                    <form action="{{ route('categories.store') }}" method="POST">
                        @csrf
                        <div class="form-group mb-3">
                            <label for="name" class="form-label">Название категории</label>
                            <input type="text" id="name" name="name" class="form-control">
                        </div>
                        <button type="submit" class="btn btn-dark btn-lg">Создать</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
@endsection
