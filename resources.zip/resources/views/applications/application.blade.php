@extends('app')

@section('title', __('Заявка'))

@section('content')

    <div class="row block-application">
        {{-- <div class=""> --}}
        <img class="" src="{{ asset('assets/images/design-interera-foto-2 1.jpg') }}" alt="">

        <div class="card-img-overlay p-5">
            <h1 class="fw-bold">УЮТНЫЙ ДИЗАЙН ИНТЕРЬЕРА ПО ВАШЕМУ ВКУСУ</h1>
            <p class="my-5 fw-semibold fs-5">Задача дизайнера — сделать ваш дом не только красивым, но и идеально вам
                подходящим.</p>
            <div class="row d-flex p-5">
                <div class="row block-application-text d-flex p-5">
                    <div class="d-flex flex-row mb-3 align-items-end justify-content-between">
                        {{-- <div class="p-2"> --}}
                        <img src="{{ asset('assets/images/Group 234.png') }}" alt="">
                        {{-- </div> --}}
                        <div class="p-2">
                            <h3>Планировочное решение</h3>
                        </div>
                    </div>
                    <div class="d-flex flex-row mb-3 align-items-end justify-content-between">
                        <img src="{{ asset('assets/images/Group 235.png') }}" alt="">
                        <h3 class="p-2">Эскизы</h3>
                    </div>
                    <div class="d-flex flex-row mb-3 align-items-end justify-content-between">
                        <img src="{{ asset('assets/images/Group 236.png') }}" alt="">
                        <h3 class="p-2">3D-визуализация</h3>
                    </div>
                    <div class="d-flex flex-row mb-3 align-items-end justify-content-between">
                        <img src="{{ asset('assets/images/Group 237.png') }}" alt="">
                        <h3 class="p-2">Рабочая документация</h3>
                    </div>
                </div>
                <div class="row block-application-form">
                    <div class="p-3">
                        <h3 class="">ОСТАВИТЬ ЗАЯВКУ НА </h3>
                        <h3 class="">РАСЧЁТ СТОИМОСТИ</h3>
                        <div class="">

                            <form action="{{ route('auth.store-user') }}" method="POST">
                                @csrf
                                <div class="form-group mb-3 text-start px-5">
                                    <label for="name" class="form-label">Ваше имя:</label>
                                    <input type="text" id="name" name="name" class="form-control"
                                        placeholder="Имя" value="{{ old('name') }}" required>
                                    @error('name')
                                        <small class="text-danger">{{ $message }}</small>
                                    @enderror
                                </div>
                                <div class="form-group mb-3 text-start px-5">
                                    <label for="email" class="form-label">Ваш email:</label>
                                    <input type="text" id="email" name="email" class="form-control"
                                        placeholder="Email" value="{{ old('email') }}" required>
                                    @error('email')
                                        <small class="text-danger">{{ $message }}</small>
                                    @enderror
                                </div>


                                <button type="submit" class="btn btn-light m-2" data-bs-toggle="modal"
                                    data-bs-target="#exampleModal">Оставить заявку</button>
                            </form>

                            <div class="d-flex flex-row justify-content-evenly align-items-end mt-4">
                                <div>
                                    <img src="{{ asset('assets/images/Vector.png') }}" alt="">
                                </div>

                                <p class="mb-0 text-white">Ваши данные защищины</p>
                            </div>
                        </div>
                        <!-- Button trigger modal -->
                        {{-- <button type="button" class="btn btn-primary" data-bs-toggle="modal"
                            data-bs-target="#exampleModal">
                            Launch demo modal
                        </button> --}}

                        <!-- Modal -->
                        {{-- <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel"
                            aria-hidden="true">
                            <div class="modal-dialog">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <h1 class="modal-title fs-5" id="exampleModalLabel">Modal title</h1>
                                        <button type="button" class="btn-close" data-bs-dismiss="modal"
                                            aria-label="Close"></button>
                                    </div>
                                    <div class="modal-body">
                                        ...
                                    </div>
                                    <div class="modal-footer">
                                        <button type="button" class="btn btn-secondary"
                                            data-bs-dismiss="modal">Close</button>
                                        <button type="button" class="btn btn-primary">Save changes</button>
                                    </div>
                                </div>
                            </div>
                        </div> --}}

                    </div>
                </div>
            </div>


        </div>

        {{-- </div> --}}

    </div>



@endsection
