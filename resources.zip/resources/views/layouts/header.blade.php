<header class="sticky-top">
    {{-- <nav class="navbar navbar-expand-lg bg-dark " data-bs-theme="dark">
        <div class="container">

            <a class="navbar-brand text-uppercase fw-bold" href="{{ route('app.main') }}"><img
                    src="{{ asset('assets/images/Logo.png') }}" alt="Logo"></a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse"
                data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false"
                aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse d-flex justify-content-between" id="navbarSupportedContent">
                <ul class="navbar-nav me-auto mb-2 mb-lg-0">


                    <li class="nav-item ">
                        <a class="nav-link" aria-current="page"
                            href="{{ route('app.services.page') }}">{{ __('app.menu.services') }}</a>
                    </li>
                    <li class="nav-item ">
                        <a class="nav-link" aria-current="page"
                            href="{{ route('app.blogs.index') }}">{{ __('app.menu.blog') }}</a>
                    </li>
                    <li class="nav-item ">
                        <a class="nav-link" href="{{ route('app.gallers.index') }}">{{ __('app.menu.gallery') }}</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" aria-current="page"
                            href="{{ route('app.contacts.index') }}">{{ __('app.menu.contacts') }}</a>
                    </li>
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="" role="button" data-bs-toggle="dropdown"
                            aria-expanded="false">
                            {{ __('Жанры') }}
                        </a>
                        <ul class="dropdown-menu">
                            @foreach ($genres as $genre)
                                <li>
                                    <a class="dropdown-item" href="{{ route('app.catalog-by-genre', $genre->slug) }}">
                                        {{ $genre->name }}
                                    </a>
                                </li>
                            @endforeach
                        </ul>
                    </li>
                </ul>
                <ul class="navbar-nav mb-2 mb-lg-0 d-flex align-items-center justify-content-end">
                    @unlessrole('user')
                        <li class="nav-link dropdown mx-3">
                            <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown"
                                aria-expanded="false">
                                консоль
                            </a>
                            <ul class="dropdown-menu">
                                @hasanyrole('super-admin|admin')
                                    <li>
                                        <a class="dropdown-item" href="{{ route('categories.list') }}">
                                            Категории
                                        </a>
                                    </li>
                                @endhasanyrole
                                @hasanyrole('super-admin|admin')
                                    <li>
                                        <a class="dropdown-item" href="{{ route('articles.index') }}">
                                            Новости
                                        </a>
                                    </li>
                                @endhasanyrole
                                @hasanyrole('super-admin|admin')
                                    <li>
                                        <a class="dropdown-item" href="{{ route('books.index') }}">
                                            {{ __('Project') }}
                                        </a>
                                    </li>
                                @endhasanyrole
                                @hasanyrole('super-admin|admin')
                                    <li>
                                        <a class="dropdown-item" href="{{ route('genres.index') }}">
                                            {{ __('Genres') }}
                                        </a>
                                    </li>
                                @endhasanyrole
                                @hasanyrole('super-admin|admin')
                                    <li>
                                        <a class="dropdown-item" href="{{ route('users.index') }}">
                                            {{ __('Пользователи') }}
                                        </a>
                                    </li>
                                @endhasanyrole
                                @hasrole('super-admin')
                                    <li>
                                        <a class="dropdown-item" href="{{ route('roles.index') }}">
                                            {{ __('Роли') }}
                                        </a>
                                    </li>
                                @endhasrole
                                @hasrole('super-admin')
                                    <li>
                                        <a class="dropdown-item" href="{{ route('permissions.index') }}">
                                            {{ __('Права') }}
                                        </a>
                                    </li>
                                @endhasrole
                            </ul>
                        </li>
                    @endunlessrole
                    <li class="nav-item dropdown ">
                        <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown"
                            aria-expanded="false">
                            {{ __('Lang') }}
                        </a>
                        <ul class="dropdown-menu">
                            <li><a class="dropdown-item" href="{{ route('app.change-lang', 'en') }}">Английский</a>
                            </li>
                            <li><a class="dropdown-item" href="{{ route('app.change-lang', 'ru') }}">Русский</a></li>
                        </ul>
                    </li>
                    @if (auth()->user())
                        <li class="nav-item text-light mx-3">
                            {{ auth()->user()->name }}
                        </li>
                        <li class="nav-item text-light mx-3">
                            <form action="{{ route('auth.logout') }}" method="POST">
                                @csrf
                                <button type="submit"
                                    class="btn btn-sm btn-danger">{{ __('app.menu.logout') }}</button>
                            </form>
                        </li>
                    @else
                        <li class="nav-item">
                            <a class="nav-link" aria-current="page" href="{{ route('auth.register') }}">Регистрация</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" aria-current="page" href="{{ route('auth.login-page') }}">Вход</a>
                        </li>
                    @endif
                </ul>
            </div>
        </div>
    </nav> --}}


    <nav class="navbar navbar-expand-lg bg-body-tertiary" data-bs-theme="dark">
        <div class="container">
            <a class="navbar-brand text-uppercase fw-bold" href="{{ route('app.main') }}"><img
                    src="{{ asset('assets/images/Logo.png') }}" alt="Logo"></a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse"
                data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false"
                aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarSupportedContent">
                <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                    <li class="nav-item pe-3">
                        <a class="nav-link " aria-current="page"
                            href="{{ route('app.services.page') }}">{{ __('app.menu.services') }}</a>
                    </li>
                    <li class="nav-item pe-3">
                        <a class="nav-link" aria-current="page"
                            href="{{ route('app.blogs.index') }}">{{ __('app.menu.blog') }}</a>
                    </li>
                    <li class="nav-item pe-3">
                        <a class="nav-link" href="{{ route('app.gallers.index') }}">{{ __('app.menu.gallery') }}</a>
                    </li>
                    <li class="nav-item pe-3">
                        <a class="nav-link" aria-current="page"
                            href="{{ route('app.contacts.index') }}">{{ __('app.menu.contacts') }}</a>
                    </li>

                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown"
                            aria-expanded="false">
                            {{ __('Стили') }}
                        </a>
                        <ul class="dropdown-menu">
                            @foreach ($genres as $genre)
                                <li>
                                    <a class="dropdown-item"
                                        href="{{ route('app.catalog-by-genre', $genre->slug) }}">
                                        {{ $genre->name }}
                                    </a>
                                </li>
                            @endforeach
                        </ul>

                    </li>

                </ul>
                <ul class="navbar-nav mb-lg-0 align-items-center">
                    @unlessrole('user')
                        <li class="nav-link dropdown pe-3">
                            <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown"
                                aria-expanded="false">
                                {{ __('Консоль') }}

                            </a>
                            <ul class="dropdown-menu">
                                @hasanyrole('super-admin|admin')
                                    <li>
                                        <a class="dropdown-item" href="{{ route('categories.list') }}">
                                            {{ __('Категории') }}

                                        </a>
                                    </li>
                                @endhasanyrole
                                @hasanyrole('super-admin|admin')
                                    <li>
                                        <a class="dropdown-item" href="{{ route('articles.index') }}">
                                            {{ __('Тема') }}
                                        </a>
                                    </li>
                                @endhasanyrole
                                @hasanyrole('super-admin|admin')
                                    <li>
                                        <a class="dropdown-item" href="{{ route('books.index') }}">
                                            {{ __('Проекты') }}
                                        </a>
                                    </li>
                                @endhasanyrole
                                @hasanyrole('super-admin|admin')
                                    <li>
                                        <a class="dropdown-item" href="{{ route('genres.index') }}">
                                            {{ __('Стили') }}
                                        </a>
                                    </li>
                                @endhasanyrole
                                @hasanyrole('super-admin|admin')
                                    <li>
                                        <a class="dropdown-item" href="{{ route('users.index') }}">
                                            {{ __('Пользователи') }}
                                        </a>
                                    </li>
                                @endhasanyrole
                                @hasrole('super-admin')
                                    <li>
                                        <a class="dropdown-item" href="{{ route('roles.index') }}">
                                            {{ __('Роли') }}
                                        </a>
                                    </li>
                                @endhasrole
                                @hasrole('super-admin')
                                    <li>
                                        <a class="dropdown-item" href="{{ route('permissions.index') }}">
                                            {{ __('Права') }}
                                        </a>
                                    </li>
                                @endhasrole
                            </ul>
                        </li>
                    @endunlessrole
                    <li class="nav-item dropdown pe-3">
                        <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown"
                            aria-expanded="false">
                            {{ __('Lang') }}
                        </a>
                        <ul class="dropdown-menu">
                            <li><a class="dropdown-item" href="{{ route('app.change-lang', 'en') }}">Английский</a>
                            </li>
                            <li><a class="dropdown-item" href="{{ route('app.change-lang', 'ru') }}">Русский</a></li>
                        </ul>
                    </li>
                    @if (auth()->user())
                        <li class="nav-item text-light mx-3">
                            {{ auth()->user()->name }}
                        </li>
                        <li class="nav-item text-light mx-3">
                            <form action="{{ route('auth.logout') }}" method="POST">
                                @csrf
                                <button type="submit"
                                    class="btn btn-sm btn-danger">{{ __('app.menu.logout') }}</button>
                            </form>
                        </li>
                    @else
                        <li class="nav-item">
                            <a class="nav-link" aria-current="page" href="{{ route('auth.register') }}">Регистрация</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" aria-current="page" href="{{ route('auth.login-page') }}">Вход</a>
                        </li>
                    @endif
                </ul>

            </div>
        </div>
    </nav>
</header>
