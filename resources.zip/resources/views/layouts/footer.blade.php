<footer class="row sticky-top">
    <nav class="navbar navbar-expand-lg bg-body-tertiary bg-dark"data-bs-theme="dark">
        <div class="container text-center flex-column">
            <div class="collapse navbar-collapse d-flex align-items-start" id="navbarSupportedContent">
                <div class="footer-image">
                    <img src="{{ asset('assets/images/images.jpg') }}" alt="">
                </div>
                <div class=" text-center footer-services">
                    <div class="row row-cols-4 navbar-nav me-auto mb-2 mb-lg-0">


                        <div class="row d-flex">
                            <div class="col nav-item">
                                <a class="nav-link" href="{{ route('app.services.page') }}">
                                    {{ __('app.menu.services') }}</a>
                            </div>
                            <div class="row d-flex footer-list">
                                <div class="nav-item">
                                    <a class="nav-link float-start" aria-current="page"
                                        href="{{ route('app.services.compound') }}">Состав дизайн-проекта</a>
                                </div>
                                <div class="nav-item">
                                    <a class="nav-link float-start" aria-current="page"
                                        href="{{ route('app.services.design') }}">Дизайн жилых помещений</a>
                                </div>
                                <div class="nav-item">
                                    <a class="nav-link float-start" aria-current="page"
                                        href="{{ route('app.services.interior') }}">Интерьеры для бизнеса</a>
                                </div>
                                <div class="nav-item">
                                    <a class="nav-link float-start" aria-current="page"
                                        href="{{ route('app.services.online') }}">Дизайн интерьера онлайн</a>
                                </div>
                            </div>

                        </div>

                        <div class="col nav-item"><a class="nav-link" aria-current="page"
                                href="{{ route('app.blogs.index') }}">{{ __('app.menu.blog') }}</a></div>
                        <div class="col nav-item"><a class="nav-link"
                                href="{{ route('app.gallers.index') }}">{{ __('app.menu.gallery') }}</a></div>
                        <div class="col nav-item">
                            <a class="nav-link" aria-current="page"
                                href="{{ route('app.contacts.index') }}">{{ __('app.menu.contacts') }}</a>
                            <div class="d-flex align-items-end flex-column mb-3">
                                <span class="nav-link text-end">ПРИСОЕДИНЯЙТЕСЬ К НАМ:</span>
                                <ul class=" d-flex mt-3">
                                    <li>
                                        <div
                                            class="footer-icon d-flex align-items-center justify-content-end mx-1 social-icons">
                                            <a class="" href="https://ok.ru/" target="_blank">
                                                <img src="{{ asset('assets/images/free-icon-odnoklassniki-3669991.png') }}"
                                                    class="footer-social-icon" alt="odnoklassniki">
                                            </a>
                                        </div>
                                    </li>
                                    <li>
                                        <div
                                            class="footer-icon d-flex align-items-center justify-content-end mx-1 social-icons">
                                            <a class="" href="https://vk.com/" target="_blank">
                                                <img src="{{ asset('assets/images/free-icon-vkontakte-3670329.png') }}"
                                                    class="footer-social-icon" alt="vkontakte">
                                            </a>
                                        </div>
                                    </li>
                                    <li>
                                        <div
                                            class="footer-icon d-flex align-items-center justify-content-end mx-1 social-icons">
                                            <a class="" href="https://www.youtube.com/@dsgninterior"
                                                target="_blank">
                                                <img src="{{ asset('assets/images/free-icon-youtube-185983.png') }}"
                                                    class="footer-social-icon" alt="youtube">
                                            </a>
                                        </div>
                                    </li>
                                    <li>
                                        <div
                                            class="footer-icon d-flex align-items-center justify-content-end mx-1 social-icons">
                                            <a class="" href="https://web.whatsapp.com/" target="_blank">
                                                <img src="{{ asset('assets/images/free-icon-whatsapp-3670133.png') }}"
                                                    class="footer-social-icon" alt="whatsapp">
                                            </a>
                                        </div>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="d-flex justify-content-evenly mb-2 ">
                <a class="navbar-brand" href="{{ route('app.main') }}"><img
                        src="{{ asset('assets/images/Logo.png') }}" alt="Logo"></a>
            </div>
        </div>

    </nav>
</footer>
