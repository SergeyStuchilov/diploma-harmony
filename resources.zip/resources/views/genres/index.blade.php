@extends('app')

@section('title', __('Стили'))

@section('content')
    <div class="row">
        <div class="card ">
            <img class="opacity-25" src="{{ asset('assets/images/glavnaya_resize.jpg') }}" alt="">
            <div class="card-img-overlay d-flex flex-column">
                <div class="d-flex justify-content-between align-items-center my-5">
                    <h2>{{ __('Стили') }}</h2>
                    <a href="{{ route('genres.create') }}" class="btn btn-dark btn-lg">Добавить</a>
                </div>
                <div>
                    <table class="table table-striped">
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>Стиль</th>
                                <th>Действия</th>
                            </tr>
                        </thead>
                        <tbody>
                            @foreach ($genres as $genre)
                                <tr>
                                    <td>{{ $loop->index + 1 }}</td>
                                    <td>{{ $genre->name }}</td>
                                    <td class="justify-content-around">
                                        {{-- <a href="{{ route('genres.edit', $genre) }}" class="btn btn-sm btn-warning">Ред.</a> --}}
                                        <form action="{{ route('genres.destroy', $genre) }}" method="POST" class="mx-3">
                                            @csrf @method('DELETE')
                                            <button type="submit" class="btn btn-sm btn-danger">Удалить</button>
                                        </form>
                                    </td>
                                </tr>
                            @endforeach
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
@endsection
