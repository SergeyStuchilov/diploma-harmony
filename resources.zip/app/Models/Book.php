<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Support\Facades\File;
use Illuminate\Support\Facades\Storage;
use Spatie\Sluggable\HasSlug;
use Spatie\Sluggable\SlugOptions;
use Intervention\Image\Facades\Image;
use Intervention\Image\ImageManager;
// use Intervention\Image\ImageManagerStatic as Image;



class Book extends Model
{
    use HasFactory, HasSlug, SoftDeletes;

    protected $fillable = [
        'title',
        'description',
        'publish_date',
        'price',
        'image'
    ];

    public function authors()
    {
        return $this->belongsToMany(Author::class);
    }

    public function genres()
    {
        return $this->belongsToMany(Genre::class);
    }

    public function getSlugOptions(): SlugOptions
    {
        return SlugOptions::create()
            ->generateSlugsFrom('title')
            ->saveSlugsTo('slug');
    }

    public function getPrice()
    {
        return number_format($this->price, 2, ',', ' ') . ' ₽';
    }

    //Выводим список жанров
    public function getGenres()
    {
        $genres = [];
        foreach ($this->genres as $genre) {
            $genres[] = '<a href="#">' . $genre->name . '</a>';
        }
        return implode(', ', $genres);
    }

    // Картинка
    public function uploadImage($file)
    {
        if ($file == null) return false;
        $filename = $file->getClientOriginalName();
        $path = 'books/book_' . $this->id . '/';
        $fullpath = 'uploads/' . $path . '/' . $filename;

        if (!File::exists('uploads/' . $path)) {
            File::makeDirectory('uploads/' . $path);
        }

        //Cоздать новый ресурс изображения из файла
        // $compressImage = Image::make($file);
        //изменить размер изображения до фиксированного размера и сохранить
        // $compressImage->resize(300, 200)->save();

        $this->removeImage();
        $file->storeAs($path, $filename, 'uploads');
        $this->image = $path . $filename;
        $this->save();

    }

    // Проверка на изображение
    // public function getImage()
    // {
    //     $image = $this->image;


    //     return $image ? asset('uploads/' . $image) : asset("assets/images/no_image.png");
    // }
    public function getImage()
    {
        $image = $this->image;

        if ($image) {
            return asset('uploads/' . $image);
        }
        return asset('assets/images/no_image.png');
    }


    // Удаление картинки
    public function removeImage()
    {
        if ($this->image) {
            Storage::disk("uploads")->delete($this->image);
            File::deleteDirectory(public_path('uploads/book_' . $this->id));
            $this->image = null;
            $this->save();
        }
    }
}
