<?php

namespace App\Http\Controllers;

use App\Models\Book;
use Illuminate\Http\Request;
use Illuminate\Pagination\Paginator;

class GalleryController extends Controller
{
    public function galleryPage(Request $request)
    {
        $books = Book::all();


        //Поиск
        // if(isset($_GET['search'])){
        //     $books = Book::where('title', 'like', "%".$_GET['search']."%")->get();
        // }

        return view('gallerys.gallery', [
            'books' => $books,
            //Пагинация
            'books' => Book::paginate(3)
        ]);
    }
    public function search(Request $request){

        $search = $request->search_books;


        $books_query = Book::query()->where('title', 'LIKE', "%{$search}%");
        $books = $books_query->paginate(3);
         return view('gallerys.gallery',compact('books'));

    }

    //Страница проекта
    public function showBook($bookSlug)
    {
        return view('gallerys.book-page', [
            'book' => Book::where('slug', $bookSlug)->first()
        ]);
    }
}
