<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class BlogController extends Controller
{
    public function showBlog()
    {
        return view('blogs.blog');
    }

    public function blogBrick()
    {
        return view('blogs.blog-brick');
    }
}
