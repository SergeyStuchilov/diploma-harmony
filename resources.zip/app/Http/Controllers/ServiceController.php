<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class ServiceController extends Controller
{
    public function servicePage()
    {
        return view('services.services-list');
    }

    public function serviceCompound()
    {
        return view('services.service-compound');
    }

    public function serviceDesign()
    {
        return view('services.service-design');
    }

    public function serviceInterior()
    {
        return view('services.sercice-interior');
    }

    public function serviceOnline()
    {
        return view('services.service-online');
    }
    
}
