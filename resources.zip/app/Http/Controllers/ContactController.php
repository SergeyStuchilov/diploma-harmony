<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class ContactController extends Controller
{
    public function showContact()
    {
        return view('contacts.contact');
    }

    public function contactPage(Request $request)
    {
        $request->validate([
            'name' => 'required',
            'email' => 'required|email',
            'phone' => 'required|phone'
        ]);

        return redirect()->route('app.main');
    }
}
