<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Models\Book;
use App\Models\Genre;

class AppController extends Controller
{
    public function mainPage()
    {
        return view("main");
    }

    // Выбор языка
    public function changeLocale(Request $request, $lang)
    {
        $request->session()->put('lang', $request->lang);
        return back();
    }


    public function getProjectsByGenre($genreSlug)
    {
        $genre = Genre::where('slug', $genreSlug)->first();
        return view('catalog', [
            'books' => $genre->books,
        ]);
    }

    public function trendPage()
    {
        return view('trends.trend');
    }

    public function applicationPage()
    {
        return view('applications.application');
    }



}
