<?php $__env->startSection('title', __('Проекты')); ?>
<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="card ">
            <img class="opacity-25" src="<?php echo e(asset('assets/images/glavnaya_resize.jpg')); ?>" alt="">
            <div class="card-img-overlay overflow-auto d-flex flex-column">
                <div class="d-flex justify-content-between align-items-center my-5">
                    <h2><?php echo e(__('Проекты')); ?></h2>
                    <a href="<?php echo e(route('books.create')); ?>" class="btn btn-dark btn-lg">Добавить</a>
                </div>
                <div>
                    <table class="table table-striped">
                        <thead>
                            <tr>
                                <th><?php echo e(__('Картинка')); ?></th>
                                <th><?php echo e(__('Проект')); ?></th>
                                <th><?php echo e(__('Стоимость')); ?></th>
                                <th><?php echo e(__('Дата')); ?></th>
                                <th><?php echo e(__('Стили')); ?></th>
                                <th>Действия</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $books; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $book): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><img src="<?php echo e($book->getImage()); ?>" alt="" style="height: 80px"></td>
                                    <td><?php echo e($book->title); ?></td>
                                    <td><?php echo e($book->getPrice()); ?></td>
                                    <td><?php echo e($book->publish_date); ?></td>
                                    <td>
                                        <?php $__currentLoopData = $book->genres; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $genre): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php echo $genre->name . '<br>'; ?>

                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </td>
                                    <td class="d-flex justify-content-around">
                                        <a href="<?php echo e(route('books.edit', $book)); ?>" class="btn btn-sm btn-warning">Ред.</a>
                                        <form action="<?php echo e(route('books.destroy', $book)); ?>" method="POST" class="mx-3">
                                            <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                                            <button type="submit" class="btn btn-sm btn-danger"
                                                onclick="event.preventDefault();if(confirm('Запись будет удалена. Продолжить?')){this.closest('form').submit();}">Удалить</button>
                                        </form>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\diploma-harmony\resources\views/books/index.blade.php ENDPATH**/ ?>