<header class="sticky-top">
    <nav class="navbar navbar-expand-sm bg-dark " data-bs-theme="dark">
        <div class="container">
            
            <a class="navbar-brand text-uppercase fw-bold" href="<?php echo e(route('app.main')); ?>"><img
                    src="<?php echo e(asset('assets/images/Logo.png')); ?>" alt="Logo"></a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse"
                data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false"
                aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse d-flex justify-content-between" id="navbarSupportedContent">
                <ul class="navbar-nav me-auto mb-2 mb-lg-0">

                    
                    
                    
                    
                    <li class="nav-item mx-3">
                        <a class="nav-link" aria-current="page"
                            href="<?php echo e(route('app.services.page')); ?>"><?php echo e(__('app.menu.services')); ?></a>
                    </li>
                    <li class="nav-item mx-3">
                        <a class="nav-link" aria-current="page"
                            href="<?php echo e(route('app.blogs.index')); ?>"><?php echo e(__('app.menu.blog')); ?></a>
                    </li>
                    <li class="nav-item mx-3">
                        <a class="nav-link" href="<?php echo e(route('app.gallers.index')); ?>"><?php echo e(__('app.menu.gallery')); ?></a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" aria-current="page"
                            href="<?php echo e(route('app.contacts.index')); ?>"><?php echo e(__('app.menu.contacts')); ?></a>
                    </li>
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="" role="button" data-bs-toggle="dropdown"
                            aria-expanded="false">
                            <?php echo e(__('Жанры')); ?>

                        </a>
                        <ul class="dropdown-menu">
                            <?php $__currentLoopData = $genres; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $genre): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><a class="dropdown-item" href="<?php echo e(route('app.catalog-by-genre', $genre->slug)); ?>">
                                        <?php echo e($genre->name); ?>

                                    </a>
                                </li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </li>
                </ul>
                <ul class="navbar-nav mb-2 mb-lg-0 d-flex align-items-center justify-content-end">
                    <?php if(! \Spatie\Permission\PermissionServiceProvider::bladeMethodWrapper('hasRole', 'user')): ?>
                        <li class="nav-item dropdown mx-3">
                            <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown"
                                aria-expanded="false">
                                консоль
                            </a>
                            <ul class="dropdown-menu">
                                <?php if(\Spatie\Permission\PermissionServiceProvider::bladeMethodWrapper('hasAnyRole', 'super-admin|admin')): ?>
                                    <li>
                                        <a class="dropdown-item" href="<?php echo e(route('categories.list')); ?>">
                                            Категории
                                        </a>
                                    </li>
                                <?php endif; ?>
                                <?php if(\Spatie\Permission\PermissionServiceProvider::bladeMethodWrapper('hasAnyRole', 'super-admin|admin')): ?>
                                    <li>
                                        <a class="dropdown-item" href="<?php echo e(route('articles.index')); ?>">
                                            Новости
                                        </a>
                                    </li>
                                <?php endif; ?>
                                <?php if(\Spatie\Permission\PermissionServiceProvider::bladeMethodWrapper('hasAnyRole', 'super-admin|admin')): ?>
                                    <li>
                                        <a class="dropdown-item" href="<?php echo e(route('books.index')); ?>">
                                            <?php echo e(__('Project')); ?>

                                        </a>
                                    </li>
                                <?php endif; ?>
                                <?php if(\Spatie\Permission\PermissionServiceProvider::bladeMethodWrapper('hasAnyRole', 'super-admin|admin')): ?>
                                    <li>
                                        <a class="dropdown-item" href="<?php echo e(route('genres.index')); ?>">
                                            <?php echo e(__('Genres')); ?>

                                        </a>
                                    </li>
                                <?php endif; ?>
                                <?php if(\Spatie\Permission\PermissionServiceProvider::bladeMethodWrapper('hasAnyRole', 'super-admin|admin')): ?>
                                    <li>
                                        <a class="dropdown-item" href="<?php echo e(route('users.index')); ?>">
                                            <?php echo e(__('Пользователи')); ?>

                                        </a>
                                    </li>
                                <?php endif; ?>
                                <?php if(\Spatie\Permission\PermissionServiceProvider::bladeMethodWrapper('hasRole', 'super-admin')): ?>
                                    <li>
                                        <a class="dropdown-item" href="<?php echo e(route('roles.index')); ?>">
                                            <?php echo e(__('Роли')); ?>

                                        </a>
                                    </li>
                                <?php endif; ?>
                                <?php if(\Spatie\Permission\PermissionServiceProvider::bladeMethodWrapper('hasRole', 'super-admin')): ?>
                                    <li>
                                        <a class="dropdown-item" href="<?php echo e(route('permissions.index')); ?>">
                                            <?php echo e(__('Права')); ?>

                                        </a>
                                    </li>
                                <?php endif; ?>
                            </ul>
                        </li>
                    <?php endif; ?>
                    <li class="nav-item dropdown mx-3">
                        <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown"
                            aria-expanded="false">
                            <?php echo e(__('Lang')); ?>

                        </a>
                        <ul class="dropdown-menu">
                            <li><a class="dropdown-item" href="<?php echo e(route('app.change-lang', 'en')); ?>">Английский</a>
                            </li>
                            <li><a class="dropdown-item" href="<?php echo e(route('app.change-lang', 'ru')); ?>">Русский</a></li>
                        </ul>
                    </li>
                    <?php if(auth()->user()): ?>
                        <li class="nav-item text-light mx-3">
                            <?php echo e(auth()->user()->name); ?>

                        </li>
                        <li class="nav-item text-light mx-3">
                            <form action="<?php echo e(route('auth.logout')); ?>" method="POST">
                                <?php echo csrf_field(); ?>
                                <button type="submit"
                                    class="btn btn-sm btn-danger"><?php echo e(__('app.menu.logout')); ?></button>
                            </form>
                        </li>
                    <?php else: ?>
                        <li class="nav-item">
                            <a class="nav-link" aria-current="page" href="<?php echo e(route('auth.register')); ?>">Регистрация</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" aria-current="page" href="<?php echo e(route('auth.login-page')); ?>">Вход</a>
                        </li>
                    <?php endif; ?>
                </ul>
            </div>
        </div>
    </nav>
</header>
<?php /**PATH C:\xampp\htdocs\diploma-harmony\resources\views\layouts\header.blade.php ENDPATH**/ ?>