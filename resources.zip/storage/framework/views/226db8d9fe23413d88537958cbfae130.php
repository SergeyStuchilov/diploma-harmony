<?php $__env->startSection('title', __('Галерея')); ?>

<?php $__env->startSection('content'); ?>

    <div class="row">
        <div class="d-flex align-items-center justify-content-between mb-2">
            <h1 class="my-2"><?php echo e(__('Галерея')); ?></h1>
            <div class="d-flex">
                <form  method="GET"  action="<?php echo e(route('search')); ?>" class="d-flex mx-2" role="search">
                    <input class="form-control me-2" type="text" name="search_books" placeholder="Введите запрос" aria-label="Search" value="<?php echo e(request()->search_books); ?>">
                    <button class="btn btn-outline-success" type="submit">Найти</button>
                </form>
                <a href="<?php echo e(route('app.gallers.index')); ?>" class="btn btn-primary">Сбросить фильтр</a>
            </div>
        </div>
        <div class="card ">
            <div class="gallery-block"></div>
            
            <div class="card-img-overlay">
                <div class="row d-flex justify-content-evenly">
                    <?php $__currentLoopData = $books; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $book): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-lg-3 col-md-4 col-6 m-3">
                            <div class="card mb-3">
                                <img src="<?php echo e($book->getImage()); ?>" class="card-img-top" alt="...">
                                <div class="card-body">
                                    <h5 class="card-title"><?php echo e($book->title); ?></h5>
                                    <p class="card-text">Стоимость от <?php echo e($book->getPrice()); ?> за 1 м²</p>
                                    <a href="<?php echo e(route('app.book.page', $book->slug)); ?>" class="btn btn-primary">Перейти</a>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <div class="btn-toolbar justify-content-center" role="toolbar" aria-label="Toolbar with button groups">
                    <div class="btn-group me-2" role="group" aria-label="First group">
                        <?php if($books->currentPage() != 1): ?>
                            <a href="<?php echo e($books->previousPageUrl()); ?>" type="button" class="btn btn-lg btn-primary"><span
                                    aria-hidden="true">&laquo;</span></a>
                        <?php endif; ?>
                        <?php for($i = 1; $i <= $books->LastPage(); $i++): ?>
                            <a href="<?php echo e($books->url($i)); ?>" type="button"
                                class="btn btn-lg <?php if($i == $books->currentPage()): ?> btn-primary <?php else: ?> btn-outline-primary <?php endif; ?>"><?php echo e($i); ?></a>
                        <?php endfor; ?>
                        <?php if($books->currentPage() != $books->lastPage()): ?>
                            <a href="<?php echo e($books->nextPageUrl()); ?>" type="button" class="btn btn-lg btn-primary"><span
                                    aria-hidden="true">&raquo;</span></a>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\diploma-harmony\resources\views\gallerys\gallery.blade.php ENDPATH**/ ?>