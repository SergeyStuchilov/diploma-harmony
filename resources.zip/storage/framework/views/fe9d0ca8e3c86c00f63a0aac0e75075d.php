<?php $__env->startSection('title', __('Заявка')); ?>

<?php $__env->startSection('content'); ?>

    <div class="row block-application">
        
        <img class="" src="<?php echo e(asset('assets/images/design-interera-foto-2 1.jpg')); ?>" alt="">

        <div class="card-img-overlay p-5">
            <h1 class="fw-bold">УЮТНЫЙ ДИЗАЙН ИНТЕРЬЕРА ПО ВАШЕМУ ВКУСУ</h1>
            <p class="my-5 fw-semibold fs-5">Задача дизайнера — сделать ваш дом не только красивым, но и идеально вам
                подходящим.</p>
            <div class="row d-flex p-5">
                <div class="row block-application-text d-flex p-5">
                    <div class="d-flex flex-row mb-3 align-items-end justify-content-between">
                        
                        <img src="<?php echo e(asset('assets/images/Group 234.png')); ?>" alt="">
                        
                        <div class="p-2">
                            <h3>Планировочное решение</h3>
                        </div>
                    </div>
                    <div class="d-flex flex-row mb-3 align-items-end justify-content-between">
                        <img src="<?php echo e(asset('assets/images/Group 235.png')); ?>" alt="">
                        <h3 class="p-2">Эскизы</h3>
                    </div>
                    <div class="d-flex flex-row mb-3 align-items-end justify-content-between">
                        <img src="<?php echo e(asset('assets/images/Group 236.png')); ?>" alt="">
                        <h3 class="p-2">3D-визуализация</h3>
                    </div>
                    <div class="d-flex flex-row mb-3 align-items-end justify-content-between">
                        <img src="<?php echo e(asset('assets/images/Group 237.png')); ?>" alt="">
                        <h3 class="p-2">Рабочая документация</h3>
                    </div>
                </div>
                <div class="row block-application-form">
                    <div class="p-3">
                        <h3 class="">ОСТАВИТЬ ЗАЯВКУ НА </h3>
                        <h3 class="">РАСЧЁТ СТОИМОСТИ</h3>
                        <div class="">

                            <form action="<?php echo e(route('auth.store-user')); ?>" method="POST">
                                <?php echo csrf_field(); ?>
                                <div class="form-group mb-3 text-start px-5">
                                    <label for="name" class="form-label">Ваше имя:</label>
                                    <input type="text" id="name" name="name" class="form-control"
                                        placeholder="Имя" value="<?php echo e(old('name')); ?>" required>
                                    <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <small class="text-danger"><?php echo e($message); ?></small>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="form-group mb-3 text-start px-5">
                                    <label for="email" class="form-label">Ваш email:</label>
                                    <input type="text" id="email" name="email" class="form-control"
                                        placeholder="Email" value="<?php echo e(old('email')); ?>" required>
                                    <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <small class="text-danger"><?php echo e($message); ?></small>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>


                                <button type="submit" class="btn btn-light m-2" data-bs-toggle="modal"
                                    data-bs-target="#exampleModal">Оставить заявку</button>
                            </form>

                            <div class="d-flex flex-row justify-content-evenly align-items-end mt-4">
                                <div>
                                    <img src="<?php echo e(asset('assets/images/Vector.png')); ?>" alt="">
                                </div>

                                <p class="mb-0 text-white">Ваши данные защищины</p>
                            </div>
                        </div>
                        <!-- Button trigger modal -->
                        

                        <!-- Modal -->
                        

                    </div>
                </div>
            </div>


        </div>

        

    </div>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\diploma-harmony\resources\views\applications\application.blade.php ENDPATH**/ ?>