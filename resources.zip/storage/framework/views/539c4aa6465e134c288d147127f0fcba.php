<?php $__env->startSection('title', $user->name); ?>
<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="card ">
            <img class="opacity-25" src="<?php echo e(asset('assets/images/glavnaya_resize.jpg')); ?>" alt="">
            <div class="card-img-overlay overflow-auto d-flex flex-column">
                <div class="d-flex justify-content-between align-items-center my-5">
                    <h2><?php echo e($user->name); ?></h2>
                </div>
                <div>
                    <form action="<?php echo e(route('users.update', $user)); ?>" method="POST">
                        <?php echo csrf_field(); ?> <?php echo method_field('PUT'); ?>
                        <div class="form-group mb-3">
                            <label for="name" class="form-label">Имя</label>
                            <input type="text" id="name" name="name" class="form-control"
                                value="<?php echo e(old('name', $user->name)); ?>">
                            <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <small class="text-danger"><?php echo e($message); ?></small>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <?php if($user->id != auth()->user()->id): ?>
                            <div class="form-group mb-3">
                                <p>Роли</p>
                                <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <label for="<?php echo e('role_' . $role->id); ?>" class="form-label mx-2">
                                        <input type="checkbox" id="<?php echo e('role_' . $role->id); ?>" name="roles[]"
                                            class="form-check-input" value="<?php echo e($role->name); ?>"
                                            <?php if($user->roles->contains(old('role_' . $role->id, $role->id))): ?> checked <?php endif; ?>>
                                        <?php echo e($role->name); ?>

                                    </label>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                            <div class="form-group mb-3">
                                <p>Права</p>
                                <?php $__currentLoopData = $permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $perm): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <label for="<?php echo e('permission_' . $perm->id); ?>" class="form-label mx-2">
                                        <input type="checkbox" id="<?php echo e('permission__' . $perm->id); ?>" name="permissions[]"
                                            class="form-check-input" value="<?php echo e($perm->name); ?>"
                                            <?php if($user->hasPermissionTo($perm->name)): ?> checked <?php endif; ?>>
                                        <?php echo e($perm->name); ?>

                                    </label>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        <?php endif; ?>
                        <button type="submit" class="btn btn-dark btn-lg">Изменить</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\diploma-harmony\resources\views/users/edit-user.blade.php ENDPATH**/ ?>