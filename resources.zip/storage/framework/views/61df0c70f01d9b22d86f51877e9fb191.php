<?php $__env->startSection('title', __('Кирпичная стена в интерьере: брутальный акцент')); ?>

<?php $__env->startSection('content'); ?>

    <div class="row">
        <div class="card ">
            <img class="opacity-25" src="<?php echo e(asset('assets/images/glavnaya_resize.jpg')); ?>" alt="">
            <div class="card-img-overlay overflow-auto text-start px-5 mx-4">
                <h2 class="my-3 text-center"><?php echo e(__('Кирпичная стена в интерьере: брутальный акцент')); ?></h2>
                <div class="row ">
                    <div>
                        <p>
                            Популярная кирпичная стена в интерьере квартиры – это дань индустриальной моде и изящный акцент
                            из мира нью-йоркских мануфактур. Все дизайны – от классики и модерна до строгого «сканди» –
                            пытаются заигрывать с этим видом отделки. Ведь на фоне кладки из кирпича эффектно смотрится
                            современное искусство, сверкает инновационными материалами бытовая техника, а оригинальная
                            дизайнерская мебель начинает виртуозно солировать.
                        </p>
                    </div>
                    <div class="d-flex my-5 justify-content-between">
                            <img src="<?php echo e(asset('assets/images/kirpichnaya-stena-v-interere27 1.jpg')); ?>" alt="">
                            <img src="<?php echo e(asset('assets/images/kirpichnaya-stena-v-interere38 1.jpg')); ?>" alt="">
                            <img src="<?php echo e(asset('assets/images/kirpichnaya-stena-v-interere17 1.jpg')); ?>" alt="">
                            <img src="<?php echo e(asset('assets/images/kirpichnaya-stena-v-interere10 1.jpg')); ?>" alt="">
                    </div>
                    <div>
                        <p>
                            Спальня, гостиная или столовая с декором из кирпича приобретает несколько брутальный,
                            индустриальный оттенок. Такая оригинальная деталь внутренней отделки сегодня популярна не только
                            в загородных домах, но и в столичных апартаментах.
                        </p>
                    </div>
                    <div>
                        <p>
                            Фрагмент кирпичной кладки уместен в скандинавском интерьере. Камень может быть как красным, так
                            и белым, в том числе окрашенным. Если добавить в помещение «согревающие» детали – камин,
                            пушистый ковер, овечью шкуру, плед крупной вязки, – получится уютный дизайн с неформальным,
                            городским акцентом.
                        </p>
                    </div>
                    <div>
                        <p>
                            Органичнее всего кирпичная кладка выглядит в интерьере лофт. На подобной стене хорошо смотрится
                            не только телевизор, но и, к примеру, яркие постеры, живопись, автомобильные номера и даже
                            подвесные велосипеды. В гостиной на кирпичном фрагменте можно организовать ниши с книгами или
                            полки для фотографий.
                        </p>
                    </div>

                    <div class="d-flex my-5 justify-content-between">
                            <img src="<?php echo e(asset('assets/images/kirpichnaya-stena-v-interere42 1.jpg')); ?>" alt="">
                            <img src="<?php echo e(asset('assets/images/kirpichnaya-stena-v-interere19 1.jpg')); ?>" alt="">
                            <img src="<?php echo e(asset('assets/images/kirpichnaya-stena-v-interere14 1.jpg')); ?>" alt="">
                            <img src="<?php echo e(asset('assets/images/kirpichnaya-stena-v-interere31 1.jpg')); ?>" alt="">
                    </div>
                    <div>
                        <p>
                            Промышленный дизайн набирает обороты: несмотря на скупость обстановки, жить на этих свободных
                            просторах весьма комфортно. В компаньоны кирпичу можно взять стекло, сталь, натуральное дерево
                            (балки, лаги, стропила) и бетон (заливка пола, оформление стен и колонн). Нетривиально смотрится
                            кирпичный фартук на кухне – очередная дань индустриальному направлению.
                        </p>
                    </div>
                    <div>
                        <p>
                            Рустик, кантри, шале – в целом, все деревенские направления благосклонно относятся как к кирпичу
                            естественного оттенка, так и к натуральному камню. В стиле кантри актуальны арочные проемы,
                            отделанные видавшим виды красным кирпичом. В загородных домах нередко обрамляют им область
                            вокруг камина, закрывая часть стены до самого потолка.
                        </p>
                    </div>

                </div>

            </div>
        </div>


    </div>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\diploma-harmony\resources\views\blogs\blog-brick.blade.php ENDPATH**/ ?>