<?php $__env->startSection('title', __('Тема')); ?>
<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="card ">
            <img class="opacity-25" src="<?php echo e(asset('assets/images/glavnaya_resize.jpg')); ?>" alt="">
            <div class="card-img-overlay overflow-auto d-flex flex-column">
                <div class="d-flex justify-content-between align-items-center my-5">
                    <h2><?php echo e(__('Тема')); ?></h2>
                    <a href="<?php echo e(route('articles.create')); ?>" class="btn btn-dark btn-lg">Добавить</a>
                </div>
                <?php if(session('success')): ?>
                    <div class="alert alert-success">
                        <?php echo e(session('success')); ?>

                    </div>
                <?php endif; ?>
                <div>
                    <?php if($articles->count()): ?>
                        <table class="table table-striped">
                            <thead>
                                <tr>
                                    <th>Изображение</th>
                                    <th>Заголовок</th>
                                    <th>Категория</th>
                                    <th>Опубликовано</th>
                                    <th>Действие</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $articles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $article): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td>
                                            <img src="<?php echo e($article->getImage()); ?>" alt="" style="height: 80px">
                                        </td>
                                        <td>
                                            <a href="<?php echo e(route('articles.show', $article->slug)); ?>">
                                                <?php echo e($article->title); ?>

                                            </a>
                                        </td>
                                        <td><?php echo e($article->category->name); ?></td>
                                        <td><?php echo $article->getPublishStatus(); ?></td>
                                        <td class="d-flex justify-content-around">
                                            <a href="<?php echo e(route('articles.edit', $article)); ?>"
                                                class="btn btn-sm btn-warning">Ред.</a>
                                            <form action="<?php echo e(route('articles.delete', $article)); ?>" method="POST"
                                                class="mx-3">
                                                <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                                                <button type="submit" class="btn btn-sm btn-danger"
                                                    onclick="event.preventDefault();if(confirm('Запись будет удалена. Продолжить?')){this.closest('form').submit();}">
                                                    Удалить
                                                </button>
                                            </form>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    <?php else: ?>
                        <p class="my-4">Пока нет ни одной новости.</p>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\diploma-harmony\resources\views/articles/articles-list.blade.php ENDPATH**/ ?>