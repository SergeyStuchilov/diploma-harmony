<h2><?php echo e($user->name); ?>, cпасибо за регистрацию!</h2>
<p>Ваш логин: <?php echo e($user->email); ?></p>
<?php /**PATH C:\xampp\htdocs\diploma-harmony\resources\views\mails\register-success.blade.php ENDPATH**/ ?>