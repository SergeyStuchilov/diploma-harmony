<?php $__env->startSection('title', 'Новости'); ?>
<?php $__env->startSection('content'); ?>
    <div class="d-flex justify-content-between align-items-center my-5">
        <h2>Новости</h2>
        <a href="<?php echo e(route('articles.create')); ?>" class="btn btn-primary">Добавить</a>
    </div>

    <div>
        <h1><?php echo e($article->title); ?></h1>
        <p><?php echo e($article->content); ?></p>
        <p>Категории: <?php echo e($article->category->name); ?></p>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\diploma-harmony\resources\views\articles\show-article.blade.php ENDPATH**/ ?>