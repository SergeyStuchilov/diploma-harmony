<?php $__env->startSection('title', 'Главная'); ?>

<?php $__env->startSection('content'); ?>
    <section>
        <div class="row">
            <div class="card ">
                <div class="row home-page-image">
                    <img src="<?php echo e(asset('assets/images/glavnaya_resize.jpg')); ?>" alt="">
                </div>
                <div class="card-img-overlay home-text order-2 col-12 col-sm-6 order-sm-1  top-25 start-25">
                    <div>
                        <div>
                            <p class="row  home-text-block-text">Окунитесь в мир вашего уюта и комфорта.</p>
                        </div>
                        <h1 class="row align-self-start fw-bold">Тренды Интерьера</h1>
                        <div>
                            <a href="<?php echo e(route('app.trends.page')); ?>" type="button"
                                class="btn btn-dark btn-lg d-grid gap-2 col-6">Посмотри</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <section>
        <div class="row mb-5 my-5">
            <p>Дизайн-проекты полного цикла:</p>
            <p>Концепция, проект, комплектация, реализация, сопровождение</p>
            <h2>наши проекты</h2>
            

            <div id="carouselExampleCaptions" class="carousel slide mt-3">
                <div class="carousel-indicators">
                  <button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="0" class="active" aria-current="true" aria-label="Slide 1"></button>
                  <button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="1" aria-label="Slide 2"></button>
                  <button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="2" aria-label="Slide 3"></button>
                </div>
                <div class="carousel-inner">
                  <div class="carousel-item active">
                    <img src="<?php echo e(asset('assets/images/gotika_vid_9.jpg')); ?>" class="d-block w-100" alt="">
                    <div class="carousel-caption d-none d-md-block">
                      <h5>Готический стиль</h5>
                      <p>Смелое решение</p>
                    </div>
                  </div>
                  <div class="carousel-item">
                    <img src="<?php echo e(asset('assets/images/7665c8d11b383bed9afac71ba5dff2b2.jpg')); ?>" class="d-block w-100" alt="">
                    <div class="carousel-caption d-none d-md-block">
                      <h5>Монохромный дизайн интерьера</h5>
                      <p>Уютное пространство</p>
                    </div>
                  </div>
                  <div class="carousel-item">
                    <img src="<?php echo e(asset('assets/images/1880x1491_0xac120003_19826483531576489356.jpg')); ?>" class="d-block w-100" alt="">
                    <div class="carousel-caption d-none d-md-block">
                      <h5>Современный интерьер в стиле фьюжн</h5>
                      <p>Яркая жизнь</p>
                    </div>
                  </div>
                </div>
                <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide="prev">
                  <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                  <span class="visually-hidden">Previous</span>
                </button>
                <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide="next">
                  <span class="carousel-control-next-icon" aria-hidden="true"></span>
                  <span class="visually-hidden">Next</span>
                </button>
              </div>


            <div class="d-flex mt-5">
                <hr>
                <a href="<?php echo e(route('app.gallers.index')); ?>" class="btn btn-md btn-dark d-grid gap-2 col-6 mx-auto">Посмотреть
                    все проекты</a>
                <hr>
            </div>
        </div>
    </section>
    <section>
        <div class="home-info row">
            <div class=" row">
                <img class="home-info-image"
                    src="<?php echo e(asset('assets/images/1642214400_1-bigfoto-name-p-sovremennii-temnii-interer-1.jpg')); ?>"
                    alt="">
            </div>
            <div class="row home-info-text d-flex col-12 col-sm-6 col-md-8">
                <div class="row">
                    <h2>Узнай стоимость эксkлюзивного дизайна интерьера под ключ</h2>
                </div>
                <div class="d-grid gap-2 col-6 mx-auto">
                    <a href="<?php echo e(route('app.applications.page')); ?>" type="button" class="btn btn-dark btn-lg">Узнать</a>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\diploma-harmony\resources\views/main.blade.php ENDPATH**/ ?>