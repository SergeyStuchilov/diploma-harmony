<?php $__env->startSection('title', __('Project')); ?>
<?php $__env->startSection('content'); ?>
    <div class="d-flex justify-content-between align-items-center my-5">
        <h2><?php echo e(__('Project')); ?></h2>
        <a href="<?php echo e(route('books.create')); ?>" class="btn btn-primary">Добавить</a>
    </div>

    <div>
        <table class="table table-striped">
            <thead>
                <tr>
                    <th><?php echo e(__('Image')); ?></th>
                    <th><?php echo e(__('Project')); ?></th>
                    <th><?php echo e(__('Price')); ?></th>
                    <th><?php echo e(__('Publish Date')); ?></th>
                    <th><?php echo e(__('Genres')); ?></th>
                    <th>Действия</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $books; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $book): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td>#</td>
                        <td><?php echo e($book->title); ?></td>
                        <td><?php echo e($book->getPrice()); ?></td>
                        <td><?php echo e($book->publish_date); ?></td>
                        <td>
                            <?php $__currentLoopData = $book->genres; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $genre): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php echo $genre->name . '<br>'; ?>

                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </td>
                        <td class="d-flex">
                            <a href="<?php echo e(route('books.edit', $book)); ?>" class="btn btn-sm btn-warning">Ред.</a>
                            <form action="<?php echo e(route('books.destroy', $book)); ?>" method="POST" class="mx-3">
                                <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                                <button type="submit" class="btn btn-sm btn-danger"
                                    onclick="event.preventDefault();if(confirm('Запись будет удалена. Продолжить?')){this.closest('form').submit();}">Удалить</button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\diploma-harmony\resources\views\books\index.blade.php ENDPATH**/ ?>