<?php $__env->startSection('title', 'Новый стиль'); ?>
<?php $__env->startSection('content'); ?>
    <div class="d-flex justify-content-between align-items-center my-5">
        <h2>Новая категория</h2>
    </div>

    <div>
        <form action="<?php echo e(route("categories.store")); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <div class="form-group mb-3">
                <label for="name" class="form-label">Название категории</label>
                <input type="text" id="name" name="name" class="form-control">
            </div>
            <button type="submit" class="btn btn-primary">Создать</button>
        </form>
    </div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\diploma-harmony\resources\views\categories\create-category.blade.php ENDPATH**/ ?>