<?php $__env->startSection('title', 'Тренды интерьера'); ?>

<?php $__env->startSection('content'); ?>
    <h1 class="my-5"><?php echo e(__('Тренды интерьера')); ?></h1>


    

<?php $__env->stopSection(); ?>



<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\diploma-harmony\resources\views\trends\trend.blade.php ENDPATH**/ ?>