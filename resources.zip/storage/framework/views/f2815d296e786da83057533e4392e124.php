<?php $__env->startSection('title', __('Каталог')); ?>

<?php $__env->startSection('content'); ?>

    <div class="row">
        <div class="card ">
            <div class="gallery-block"></div>
            
            <div class="card-img-overlay">
                <div class="row d-flex justify-content-evenly">
                    <?php $__currentLoopData = $books; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $book): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-lg-3 col-md-4 col-6 m-3">
                            <div class="card mb-3">
                                <img src="<?php echo e($book->getImage()); ?>" class="card-img-top" alt="...">
                                <div class="card-body">
                                    <h5 class="card-title"><?php echo e($book->title); ?></h5>
                                    <p class="card-text">Стоимость от <?php echo e($book->getPrice()); ?> за 1 м²</p>
                                    <a href="<?php echo e(route('app.book.page', $book->slug)); ?>" class="btn btn-primary">Перейти</a>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\diploma-harmony\resources\views\catalog.blade.php ENDPATH**/ ?>