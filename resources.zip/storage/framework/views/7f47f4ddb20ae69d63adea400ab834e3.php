<?php $__env->startSection('title', 'Проект'); ?>

<?php $__env->startSection('content'); ?>
    <h1 class="my-5"><?php echo e(__('Проект')); ?></h1>


    <div class="row">
        <div class="col-lg-6 col-12">
            <div>
                <img src="<?php echo e($book->getImage()); ?>" alt="">
            </div>
        </div>
        <div class="col-lg-6 col-12">
            <h1 class="mb-3"><?php echo e($book->title); ?></h1>
            <div class="mb-3"><?php echo $book->getGenres(); ?></div>
            <div class="mb-3"><?php echo e($book->getPrice()); ?></div>
            <div class="mb-3">
                <p><?php echo $book->description; ?></p>
            </div>
        </div>

    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\diploma-harmony\resources\views\gallerys\book-page.blade.php ENDPATH**/ ?>