<?php $__env->startSection('title', 'Главная'); ?>

<?php $__env->startSection('content'); ?>

    <div class="row">

        <div class="card ">
            
            <div class="row home-page-image">
                <img src="<?php echo e(asset('assets/images/glavnaya_resize.jpg')); ?>" alt="">
            </div>
            <div class="row card-img-overlay home-text">
                <div class="row home-text-block d-flex ">
                    <p class="text-start home-text-block-text">Окунитесь в мир вашего уюта и комфорта.</p>
                    <h1 class="text-start fw-bold">Тренды Интерьера</h1>
                </div>
                <div class="row col-6  home-text-button">
                    <a href="<?php echo e(route('app.trends.page')); ?>" type="button" class="btn btn-dark btn-lg">Посмотри</a>
                </div>
            </div>

        </div>

        <div class="row mb-5">
            <p>Дизайн-проекты полного цикла:</p>
            <p>Концепция, проект, комплектация, реализация, сопровождение</p>
            <h2>наши проекты</h2>

            <div class="row row-cols-1 row-cols-md-3 g-4">
                <div class="col">
                    <div class="card h-100">
                        <img src="<?php echo e(asset('assets/images/1880x1491_0xac120003_19826483531576489356.jpg')); ?>"
                            class="card-img-top" alt="">
                        <div class="card-body">
                            <h5 class="card-title">Современный интерьер в стиле фьюжн.</h5>
                            <p class="card-text">Яркая жизнь.</p>
                        </div>
                    </div>
                </div>
                <div class="col">
                    <div class="card h-100">
                        <img src="<?php echo e(asset('assets/images/7665c8d11b383bed9afac71ba5dff2b2.jpg')); ?>" class="card-img-top"
                            alt="">
                        <div class="card-body">
                            <h5 class="card-title">Монохромный дизайн интерьера.</h5>
                            <p class="card-text">Уютное пространство.</p>
                        </div>
                    </div>
                </div>
                <div class="col">
                    <div class="card h-100">
                        <img src="<?php echo e(asset('assets/images/gotika_vid_9.jpg')); ?>" class="card-img-top" alt="">
                        <div class="card-body">
                            <h5 class="card-title">Готический стиль.</h5>
                            <p class="card-text">Смелое решение.</p>
                        </div>
                    </div>
                </div>
            </div>
            <a href="<?php echo e(route('app.gallers.index')); ?>" class="btn btn-md btn-dark">Посмотреть все проекты</a>
        </div>
        <div class="home-info row">
            <div class=" row">
                <img class="home-info-image"
                    src="<?php echo e(asset('assets/images/1642214400_1-bigfoto-name-p-sovremennii-temnii-interer-1.jpg')); ?>"
                    alt="">
            </div>

            <div class="row home-info-text d-flex">
                <div class="row">
                    <h2>Узнай стоимость эксkлюзивного дизайна интерьера под ключ</h2>
                </div>
                <div class="d-grid gap-2 col-6 mx-auto">
                    <a href="<?php echo e(route('app.applications.page')); ?>" type="button" class="btn btn-dark btn-lg">Узнать</a>
                </div>

            </div>
        </div>

    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\diploma-harmony\resources\views\main.blade.php ENDPATH**/ ?>