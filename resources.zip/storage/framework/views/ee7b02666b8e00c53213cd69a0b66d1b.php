<?php $__env->startSection('title', __('Категории')); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="card ">
            <img class="opacity-25" src="<?php echo e(asset('assets/images/glavnaya_resize.jpg')); ?>" alt="">
            <div class="card-img-overlay d-flex flex-column">
                <div class="d-flex justify-content-between align-items-center my-5">
                    <h2><?php echo e(__('Категории')); ?></h2>
                    <a href="<?php echo e(route('categories.create')); ?>" class="btn btn-dark btn-lg">Добавить</a>
                </div>
                <div>
                    <table class="table table-striped">
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>Категория</th>
                                <th>Действия</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($category->id); ?></td>
                                    <td><?php echo e($category->name); ?></td>
                                    <td class="d-flex justify-content-around">
                                        <a href="<?php echo e(route('categories.edit', $category->id)); ?>"
                                            class="btn btn-sm btn-warning">Ред.</a>
                                        <form action="<?php echo e(route('categories.delete', $category->id)); ?>" method="POST"
                                            class="mx-3">
                                            <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                                            <button type="submit" class="btn btn-sm btn-danger">Удалить</button>
                                        </form>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\diploma-harmony\resources\views/categories/categories-list.blade.php ENDPATH**/ ?>