<?php $__env->startSection('title', __('Услуги')); ?>

<?php $__env->startSection('content'); ?>

    <div class="row">
        <div class="card ">
            <img class="opacity-25" src="<?php echo e(asset('assets/images/glavnaya_resize.jpg')); ?>" alt="">
            <div class="card-img-overlay d-flex align-items-start flex-column justify-content-evenly">
                <a href="<?php echo e(route('app.services.compound')); ?>" class="text-black">
                    <h2 class="">Состав дизайн-проекта</h2>
                </a>

                <div class="row d-flex mx-5 px-5">
                    <div class="d-flex">
                        <p class="text-start">
                            Дизайн-проект интерьера разрабатывается в среднем от 50 до 70 рабочих дней, в зависимости от
                            сложности, стиля и размера объекта, и делится на 4 этапа:
                        </p>
                    </div>

                    <div class="d-flex">
                        <h4 class="">Этап 1. Техническое задание и планировочное решение</h4>
                    </div>
                    <div class="d-flex">
                        <h4>Этап 2. Эскизный проект и черно-белая 3D визуализация</h4>
                    </div>
                    <div class="d-flex">
                        <h4>Этап 3. Цветная 3D визуализация</h4>
                    </div>
                    <div class="d-flex">
                        <h4>Этап 4. Рабочий проект</h4>
                    </div>

                </div>
                <a href="<?php echo e(route('app.services.design')); ?>" class="text-black">
                    <h2>Дизайн жилых помещений</h2>
                </a>
                <a href="<?php echo e(route('app.services.interior')); ?>" class="text-black">
                    <h2>Интерьеры для бизнеса</h2>
                </a>

                <div class="row d-flex mx-5 px-5">
                    <div class="d-flex">
                        <h4>Создание комплексных интерьерных,архитектурных решений для бизнеса</h4>
                    </div>
                    <div class="d-flex">
                        <h4>Разработка проекта,концепции</h4>
                    </div>
                    <div class="d-flex">
                        <h4>Эмоушн-дизайн</h4>
                    </div>
                    <div class="d-flex">
                        <h4>Комплектация,сопровождение</h4>
                    </div>

                </div>
                <a href="<?php echo e(route('app.services.online')); ?>" class="text-black">
                    <h2>Дизайн интерьера онлайн</h2>
                </a>
                <div class="row d-flex mx-5 px-5">
                    <p class="text-start">Дистанционный дизайн интерьера – это просто, качественно и надежно</p>
                </div>

            </div>
        </div>


    </div>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\diploma-harmony\resources\views\services\services-list.blade.php ENDPATH**/ ?>