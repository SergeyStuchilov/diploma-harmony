<?php $__env->startSection('title', __('Пользователи')); ?>
<?php $__env->startSection('content'); ?>

    <div class="row">
        <div class="card ">
            <img class="opacity-25" src="<?php echo e(asset('assets/images/glavnaya_resize.jpg')); ?>" alt="">
            <div class="card-img-overlay d-flex flex-column">
                <div class="d-flex justify-content-between align-items-center my-5">
                    <h2><?php echo e(__('Пользователи')); ?></h2>
                </div>
                <div>
                    <table class="table table-striped">
                        <thead>
                            <tr>
                                <th>ФИО</th>
                                <th>Email</th>
                                <th>Роли</th>
                                <th>Действия</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($user->name); ?></td>
                                    <td><?php echo e($user->email); ?></td>
                                    <td><?php echo e($user->getRoles()); ?></td>
                                    <td class="d-flex justify-content-around">
                                        <a href="<?php echo e(route('users.edit', $user)); ?>" class="btn btn-sm btn-warning">Ред.</a>
                                        <form action="<?php echo e(route('user.destroy', $user)); ?>" method="POST" class="mx-3">
                                            <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                                            <button type="submit" class="btn btn-sm btn-danger">Удалить</button>
                                        </form>
                                        <form action="<?php echo e(route('users.ban', $user)); ?>" method="POST" class="mx-3">
                                            <?php echo csrf_field(); ?> <?php echo method_field('PUT'); ?>
                                            <?php if($user->is_ban): ?>
                                                <button type="submit"
                                                    class="btn btn-sm btn-outline-dark">Разблокировать</button>
                                            <?php else: ?>
                                                <button type="submit" class="btn btn-sm btn-dark">Заблокировать</button>
                                            <?php endif; ?>
                                        </form>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\diploma-harmony\resources\views/users/users-list.blade.php ENDPATH**/ ?>