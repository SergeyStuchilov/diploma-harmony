<?php

return [
    'menu.home' => 'Home',
    'menu.services' => 'Services',
    'menu.gallery' => 'Gallery',
    'menu.blog' => 'Blog',
    'menu.contacts' => 'Contacts',
    'menu.logout' => 'Logout',
    'page.empty-news' => 'There is no news yet.'
];
