<?php

return [
    'menu.home' => 'Главная',
    'menu.services' => 'Услуги',
    'menu.gallery' => 'Галерея',
    'menu.blog' => 'Блог',
    'menu.contacts' => 'Контакты',
    'menu.logout' => 'Выйти',
    'page.empty-news' => 'Пока нет ни одной новости.'
];
